// AI модулі: кітап бөлімінің мәтінінен куиз, оқиға пазлы, комикс және сурет тапсырмасын дайындайды.
// Anthropic API кілті тек серверде (.env файлында) сақталады.
const API_URL = () => (process.env.ANTHROPIC_BASE_URL || 'https://api.anthropic.com').replace(/\/$/, '') + '/v1/messages';

const enabled = () => !!process.env.ANTHROPIC_API_KEY;
const model = () => process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5';

function prompt(book, i, text) {
  return `You are preparing reading activities for 4th-grade pupils (age 9-10) in Kazakhstan.
Write every string in Kazakh (Cyrillic), in short, simple, child-friendly sentences. Base every item only on the passage: do not invent events, names or details that are not in it.
Book: «${book.title}»${book.author ? ' (' + book.author + ')' : ''}. Part ${i + 1} of ${book.parts.length}: «${book.parts[i]}».
Passage:
"""
${text.slice(0, 14000)}
"""

Reply with only one JSON object of this shape:
{"quiz":[{"q":"question","o":["option","option","option"],"a":0}],
 "seq":["event","event","event","event","event"],
 "comic":{"panels":[{"scene":"short scene description","who":"character name","say":"short line the character says"}]},
 "draw":"drawing task"}
Rules:
- "quiz": exactly 4 questions about what happens and why, each with 3 options, exactly one correct; "a" is the index of the correct option; put the correct option in different positions.
- "seq": the 5 key events of this part in the order they happen, each under 10 words.
- "comic": exactly 4 panels that retell this part; "say" under 12 words; the 4th panel's "say" must be "" (the pupil will write it).
- "draw": one sentence asking the pupil to draw how they imagined a scene, place or character from this part.`;
}

function parseJson(t) {
  try { return JSON.parse(t); } catch (e) { /* төменде */ }
  const fence = t.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (fence) { try { return JSON.parse(fence[1]); } catch (e) { /* төменде */ } }
  const a = t.indexOf('{'), b = t.lastIndexOf('}');
  if (a >= 0 && b > a) { try { return JSON.parse(t.slice(a, b + 1)); } catch (e) { /* төменде */ } }
  return null;
}

// AI жауабын тексеріп, қауіпсіз пішінге келтіреді
function normalize(o) {
  if (!o || typeof o !== 'object') return null;
  const quiz = (Array.isArray(o.quiz) ? o.quiz : [])
    .map(q => ({
      q: String((q && q.q) || '').trim(),
      o: (Array.isArray(q && q.o) ? q.o : []).map(x => String(x).trim()).filter(Boolean).slice(0, 4),
      a: Number(q && q.a),
    }))
    .filter(q => q.q && q.o.length >= 2 && Number.isInteger(q.a) && q.a >= 0 && q.a < q.o.length)
    .slice(0, 5);
  if (!quiz.length) return null;
  const seq = (Array.isArray(o.seq) ? o.seq : []).map(x => String(x).trim()).filter(Boolean).slice(0, 6);
  let panels = (o.comic && Array.isArray(o.comic.panels) ? o.comic.panels : [])
    .map(p => ({
      scene: String((p && p.scene) || '').trim(),
      who: String((p && p.who) || '').trim() || 'Кейіпкер',
      say: String((p && p.say) || '').trim(),
    }))
    .filter(p => p.scene)
    .slice(0, 4);
  if (panels.length) panels[panels.length - 1].say = '';
  return {
    quiz,
    seq: seq.length >= 3 ? seq : null,
    comic: panels.length >= 3 ? { panels } : null,
    draw: String(o.draw || '').trim() || 'Бұл бөлімді оқығанда көз алдыңа не елестеді? Суретін сал.',
    ai: true,
  };
}

async function generatePart(book, i, text) {
  const res = await fetch(API_URL(), {
    method: 'POST',
    headers: {
      'x-api-key': process.env.ANTHROPIC_API_KEY,
      'anthropic-version': '2023-06-01',
      'content-type': 'application/json',
    },
    body: JSON.stringify({
      model: model(),
      max_tokens: 4000,
      messages: [{ role: 'user', content: prompt(book, i, text) }],
    }),
  });
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    const err = new Error(`AI қатесі ${res.status}: ${body.slice(0, 300)}`);
    err.status = res.status;
    throw err;
  }
  const j = await res.json();
  const out = (j.content || []).filter(c => c.type === 'text').map(c => c.text).join('');
  return normalize(parseJson(out));
}

module.exports = { enabled, model, generatePart, normalize };
