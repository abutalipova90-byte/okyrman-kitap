/* «Оқырман мектеп»: ортақ функциялар, кіру және тіркелу */
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const shuffle = a => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
const fileUrl = n => (n ? '/files/' + n : null);
const store = {
  get(k, d) { try { const v = localStorage.getItem('om:' + k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem('om:' + k, JSON.stringify(v)); } catch (e) { /* бос */ } },
};
let ME = null, STATUS = null;
let MONTHS = ['Қыркүйек', 'Қазан', 'Қараша', 'Желтоқсан', 'Қаңтар', 'Ақпан', 'Наурыз', 'Сәуір', 'Мамыр'];
const NEXT_IN = ['Қыркүйекте', 'Қазанда', 'Қарашада', 'Желтоқсанда', 'Қаңтарда', 'Ақпанда', 'Наурызда', 'Сәуірде', 'Мамырда'];
const ROLE_NAME = { admin: 'Әкімші', teacher: 'Мұғалім', student: 'Оқушы' };
const COLOR_TXT = { r: 'Оқымады немесе түсінбеді', y: 'Жартылай түсінді', g: 'Толық меңгерді' };

function toast(t, ms = 2600) {
  const d = document.createElement('div');
  d.className = 'toast';
  d.setAttribute('role', 'status');
  d.textContent = t;
  document.body.appendChild(d);
  setTimeout(() => d.remove(), ms);
}

async function api(path, opt = {}) {
  const o = { method: opt.method || 'GET', headers: {}, credentials: 'same-origin' };
  if (opt.body instanceof FormData) o.body = opt.body;
  else if (opt.body !== undefined) { o.headers['Content-Type'] = 'application/json'; o.body = JSON.stringify(opt.body); }
  let r;
  try { r = await fetch(path, o); } catch (e) { throw new Error('Серверге қосылу мүмкін болмады. Интернетті тексеріңіз'); }
  let j = null;
  try { j = await r.json(); } catch (e) { /* бос */ }
  if (r.status === 401 && ME && path !== '/api/login') { ME = null; showAuth(); throw new Error('Жүйеге қайта кіріңіз'); }
  if (!r.ok) { const e = new Error((j && j.error) || 'Қате шықты (' + r.status + ')'); e.status = r.status; throw e; }
  return j;
}

/* ---------- Белгілер ---------- */
const coin = sz => `<svg width="${sz}" height="${sz}" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="10.5" fill="#F2B632"/><circle cx="12" cy="12" r="7.6" fill="none" stroke="#C98A0B" stroke-width="1.4"/><path d="M12 7.8l1.2 2.5 2.7.4-2 1.9.5 2.7-2.4-1.3-2.4 1.3.5-2.7-2-1.9 2.7-.4Z" fill="#C98A0B"/></svg>`;
const star = (sz, on) => `<svg width="${sz}" height="${sz}" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.8l2.8 5.8 6.3.9-4.6 4.4 1.1 6.3L12 17.2l-5.6 3 1.1-6.3L2.9 9.5l6.3-.9L12 2.8Z" fill="${on ? 'var(--accent)' : 'var(--line)'}"/></svg>`;
const LOCK = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><rect x="5" y="11" width="14" height="10" rx="2" fill="#fff"/><path d="M8 11V8a4 4 0 0 1 8 0v3" stroke="#fff" stroke-width="2"/></svg>';
const LOGO_SVG = () => $('.logo') ? $('.logo').innerHTML : '';
function coverHtml(b, locked) {
  if (!b) return '';
  const lock = locked ? `<span class="lock">${LOCK}</span>` : '';
  if (b.cover) return `<div class="cover has-img${locked ? ' locked' : ''}" style="background:${esc(b.color)}">${lock}<img src="${fileUrl(b.cover)}" alt="«${esc(b.title)}» мұқабасы" loading="lazy"></div>`;
  return `<div class="cover${locked ? ' locked' : ''}" style="background:${esc(b.color)}">${lock}<span>${esc(b.author || '')}</span><b>${esc(b.title)}</b></div>`;
}

/* ---------- Конфетти ---------- */
const FXC = ['#FF5FA2', '#FFC233', '#20C9A6', '#33A8FF', '#6C4CF1', '#FF8A3D'];
let fxParts = [], fxRun = false;
const calm = () => { try { return matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) { return false; } };
function confetti(n, x, y) {
  if (calm()) return;
  const cv = $('#fx'); if (!cv) return;
  const W = innerWidth, H = innerHeight; cv.width = W; cv.height = H;
  const ox = x ?? W / 2, oy = y ?? H / 3;
  for (let k = 0; k < n; k++) {
    const a = Math.random() * Math.PI * 2, v = 4 + Math.random() * 9;
    fxParts.push({ x: ox, y: oy, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 6, r: Math.random() * 6.28, vr: (Math.random() - 0.5) * 0.4, w: 6 + Math.random() * 7, h: 4 + Math.random() * 5, c: FXC[k % FXC.length], t: 0, star: Math.random() < 0.25 });
  }
  if (!fxRun) { fxRun = true; requestAnimationFrame(fxTick); }
}
function fxTick() {
  const cv = $('#fx'), x = cv.getContext('2d');
  x.clearRect(0, 0, cv.width, cv.height);
  fxParts = fxParts.filter(p => p.t < 150 && p.y < cv.height + 40);
  fxParts.forEach(p => {
    p.t++; p.vy += 0.28; p.vx *= 0.99; p.x += p.vx; p.y += p.vy; p.r += p.vr;
    x.save(); x.translate(p.x, p.y); x.rotate(p.r); x.globalAlpha = Math.max(0, 1 - p.t / 150); x.fillStyle = p.c;
    if (p.star) { x.beginPath(); for (let k = 0; k < 10; k++) { const rr = k % 2 ? p.w * 0.45 : p.w, a = k * Math.PI / 5; x.lineTo(Math.cos(a) * rr, Math.sin(a) * rr); } x.closePath(); x.fill(); }
    else x.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
    x.restore();
  });
  if (fxParts.length) requestAnimationFrame(fxTick); else { fxRun = false; x.clearRect(0, 0, cv.width, cv.height); }
}
function burstAt(el, n) { if (!el) return confetti(n); const r = el.getBoundingClientRect(); confetti(n, r.left + r.width / 2, r.top + r.height / 2); }

/* ---------- Кітап файлдарымен жұмыс (PDF, Word, TXT) ---------- */
const PDFJS = '/vendor/pdf.min.js';
const PDFW = '/vendor/pdf.worker.min.js';
const MAMMOTH = '/vendor/mammoth.browser.min.js';
const loaded = {};
function loadScript(src) {
  return loaded[src] || (loaded[src] = new Promise((res, rej) => {
    const s = document.createElement('script'); s.src = src; s.onload = res;
    s.onerror = () => { delete loaded[src]; rej(new Error('Файл оқитын модульді жүктеу мүмкін болмады. Бетті жаңартып көріңіз')); };
    document.head.appendChild(s);
  }));
}
async function pdfLib() { await loadScript(PDFJS); pdfjsLib.GlobalWorkerOptions.workerSrc = PDFW; return pdfjsLib; }
const pdfCache = {};
async function openPdfUrl(url) {
  if (pdfCache[url]) return pdfCache[url];
  const lib = await pdfLib();
  return (pdfCache[url] = await lib.getDocument({ url, withCredentials: true }).promise);
}
async function openPdfBuffer(buf) { const lib = await pdfLib(); return lib.getDocument({ data: new Uint8Array(buf) }).promise; }
function evenRanges(pages, n) {
  const out = [];
  for (let i = 0; i < n; i++) { const a = Math.floor(i * pages / n) + 1, b = Math.floor((i + 1) * pages / n); out.push([a, Math.max(a, b)]); }
  return out;
}
function splitText(text, n) {
  const ps = text.replace(/\r/g, '').split(/\n+/).map(x => x.trim()).filter(Boolean);
  const total = ps.reduce((a, p) => a + p.length, 0);
  const out = {}; let k = 0, acc = 0, buf = [];
  ps.forEach(p => { buf.push(p); acc += p.length; if (k < n - 1 && acc >= total * (k + 1) / n) { out[k] = buf.join('\n'); buf = []; k++; } });
  out[k] = ((out[k] || '') + '\n' + buf.join('\n')).trim();
  return out;
}
async function pdfRangeTexts(doc, ranges) {
  const out = {};
  for (let i = 0; i < ranges.length; i++) {
    let t = '';
    for (let p = ranges[i][0]; p <= Math.min(ranges[i][1], doc.numPages); p++) {
      const tc = await (await doc.getPage(p)).getTextContent();
      t += tc.items.map(x => x.str).join(' ') + '\n';
    }
    out[i] = t.replace(/[ \t]+/g, ' ').trim();
  }
  return out;
}
// Файлдан мәтінді бөлімдерге бөліп алады: { pages, ranges, texts }
async function prepareEbook(file, nParts) {
  const ext = (file.name.split('.').pop() || '').toLowerCase();
  if (ext === 'pdf' || file.type === 'application/pdf') {
    const doc = await openPdfBuffer(await file.arrayBuffer());
    const ranges = evenRanges(doc.numPages, nParts);
    return { pages: doc.numPages, ranges, texts: await pdfRangeTexts(doc, ranges) };
  }
  if (ext === 'docx') {
    await loadScript(MAMMOTH);
    const r = await mammoth.extractRawText({ arrayBuffer: await file.arrayBuffer() });
    return { texts: splitText(r.value, nParts) };
  }
  if (ext === 'txt') return { texts: splitText(await file.text(), nParts) };
  throw new Error('PDF, Word (.docx) немесе .txt файлын таңдаңыз');
}
function resizeImage(file, maxW, maxH) {
  return new Promise((res, rej) => {
    if (!file || !file.type.startsWith('image/')) return rej(new Error('Сурет файлын таңдаңыз (JPG, PNG)'));
    const url = URL.createObjectURL(file), im = new Image();
    im.onload = () => {
      const k = Math.min(1, maxW / im.width, maxH / im.height), c = document.createElement('canvas');
      c.width = Math.round(im.width * k); c.height = Math.round(im.height * k);
      c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      c.toBlob(b => (b ? res(b) : rej(new Error('Суретті өңдеу мүмкін болмады'))), 'image/jpeg', 0.86);
    };
    im.onerror = () => { URL.revokeObjectURL(url); rej(new Error('Бұл суретті ашу мүмкін болмады')); };
    im.src = url;
  });
}

/* ---------- Тақырып жолағы ---------- */
function setHeader() {
  const who = $('#who'), out = $('#logout');
  $('#stars').hidden = true;
  $('#tabs').hidden = true;
  if (!ME) { who.hidden = true; out.hidden = true; return; }
  who.hidden = false;
  who.innerHTML = `<b>${esc(ME.name)}</b><span class="rolechip">${ROLE_NAME[ME.role]}</span>`;
  out.hidden = false;
}
$('#logout').onclick = async () => {
  try { await api('/api/logout', { method: 'POST' }); } catch (e) { /* бос */ }
  ME = null;
  showAuth();
};
$('#home').onclick = () => { if (ME) route(true); };

/* ---------- Іске қосу ---------- */
async function boot() {
  try { STATUS = await api('/api/status'); } catch (e) { $('#main').innerHTML = `<p class="empty">${esc(e.message)}</p>`; return; }
  if (STATUS.months) MONTHS = STATUS.months;
  if (STATUS.needsSetup) return showSetup();
  try { ME = (await api('/api/me')).user; } catch (e) { ME = null; }
  if (!ME) return showAuth();
  route();
}
function route(home) {
  setHeader();
  if (ME.role === 'student') Student.start(home);
  else Staff.start(home);
}

/* ---------- Әкімшіні алғаш тіркеу ---------- */
function authHero(sub) {
  return `<div class="auth-hero"><span class="logo">${LOGO_SVG().replace('width="28" height="28"', 'width="50" height="50"')}</span><h1>Оқырман мектеп</h1><p class="muted">${sub}</p></div>`;
}
function showSetup() {
  setHeader();
  $('#main').innerHTML = `<div class="view auth">${authHero('Сайт алғаш рет іске қосылды. Әкімшінің аккаунтын жасаңыз.')}
  <form class="card" id="setup">
    <h2>Әкімші аккаунты</h2>
    <label>Аты-жөні<input id="s-name" autocomplete="name" required></label>
    <label>Логин<input id="s-login" autocomplete="username" required placeholder="admin"></label>
    <label>Құпия сөз (кемінде 6 таңба)<input id="s-pass" type="password" autocomplete="new-password" required></label>
    <label>Құпия сөзді қайталаңыз<input id="s-pass2" type="password" autocomplete="new-password" required></label>
    <p class="err" id="s-err"></p>
    <button class="btn gold" type="submit">Әкімші ретінде тіркелу</button>
  </form></div>`;
  $('#setup').onsubmit = async e => {
    e.preventDefault();
    if ($('#s-pass').value !== $('#s-pass2').value) { $('#s-err').textContent = 'Құпия сөздер сәйкес емес'; return; }
    try {
      ME = (await api('/api/setup', { method: 'POST', body: { name: $('#s-name').value, login: $('#s-login').value, password: $('#s-pass').value } })).user;
      STATUS.needsSetup = false;
      toast('Әкімші тіркелді');
      route();
    } catch (er) { $('#s-err').textContent = er.message; }
  };
}

/* ---------- Кіру және тіркелу ---------- */
function showAuth(mode = 'login', regRole = 'student') {
  setHeader();
  const reg = mode === 'register';
  $('#main').innerHTML = `<div class="view auth">${authHero('Оқимыз • Ойланамыз • Дамимыз')}
  <div class="card">
    <div class="seg" role="group" aria-label="Кіру немесе тіркелу">
      <button type="button" id="m-login" aria-pressed="${!reg}">Кіру</button>
      <button type="button" id="m-reg" aria-pressed="${reg}">Тіркелу</button>
    </div>
    ${reg ? `<form id="regf" class="stack" style="gap:14px">
      <div class="rolepick" role="group" aria-label="Мен кіммін">
        <button type="button" data-role="student" aria-pressed="${regRole === 'student'}">Оқушымын<span>Сынып кодымен</span></button>
        <button type="button" data-role="teacher" aria-pressed="${regRole === 'teacher'}">Мұғаліммін<span>Әкімші растайды</span></button>
      </div>
      <label>Аты-жөні<input id="r-name" autocomplete="name" required placeholder="${regRole === 'student' ? 'Мысалы: Әлихан Серікұлы' : 'Мысалы: Айгүл Нұрланқызы'}"></label>
      ${regRole === 'student' ? '<label>Сынып коды<input id="r-code" required placeholder="Мұғалімің берген код" autocapitalize="characters" style="text-transform:uppercase;letter-spacing:.12em"></label>' : ''}
      <label>Логин (латын әріптерімен)<input id="r-login" autocomplete="username" required placeholder="alikhan4a"></label>
      <label>Құпия сөз (кемінде 6 таңба)<input id="r-pass" type="password" autocomplete="new-password" required></label>
      <p class="err" id="r-err"></p>
      <button class="btn gold" type="submit">Тіркелу</button>
    </form>` : `<form id="logf" class="stack" style="gap:14px">
      <label>Логин<input id="l-login" autocomplete="username" required></label>
      <label>Құпия сөз<input id="l-pass" type="password" autocomplete="current-password" required></label>
      <p class="err" id="l-err"></p>
      <button class="btn gold" type="submit">Кіру</button>
      <p class="small muted">Құпия сөзді ұмытсаң, мұғаліміңе айт: ол жаңа құпия сөз береді.</p>
    </form>`}
  </div></div>`;
  $('#m-login').onclick = () => showAuth('login');
  $('#m-reg').onclick = () => showAuth('register', regRole);
  if (reg) {
    $$('[data-role]').forEach(b => (b.onclick = () => showAuth('register', b.dataset.role)));
    $('#regf').onsubmit = async e => {
      e.preventDefault();
      const body = { role: regRole, name: $('#r-name').value, login: $('#r-login').value, password: $('#r-pass').value };
      if (regRole === 'student') body.classCode = $('#r-code').value;
      try {
        const r = await api('/api/register', { method: 'POST', body });
        if (r.pending) {
          $('#regf').outerHTML = `<div class="okbox"><b>Тіркелдіңіз!</b><br>Мұғалім аккаунтын әкімші растауы керек. Расталған соң осы логинмен кіре аласыз: <span class="pw">${esc(r.user.login)}</span></div>`;
          return;
        }
        ME = r.user;
        toast('Қош келдің!');
        route();
      } catch (er) { $('#r-err').textContent = er.message; }
    };
  } else {
    $('#logf').onsubmit = async e => {
      e.preventDefault();
      try {
        ME = (await api('/api/login', { method: 'POST', body: { login: $('#l-login').value, password: $('#l-pass').value } })).user;
        route();
      } catch (er) { $('#l-err').textContent = er.message; }
    };
  }
}
