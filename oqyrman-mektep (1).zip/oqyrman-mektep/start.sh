#!/usr/bin/env bash
cd "$(dirname "$0")"
command -v node >/dev/null || { echo "Node.js орнатылмаған: https://nodejs.org"; exit 1; }
[ -d node_modules ] || npm install --omit=dev
[ -f .env ] || cp .env.example .env
node server.js
