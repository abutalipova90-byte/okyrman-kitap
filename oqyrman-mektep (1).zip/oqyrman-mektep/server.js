// «Оқырман мектеп» сервері: тіркелу, кіру, рөлдер (әкімші, мұғалім, оқушы), кітаптар, тапсырмалар, бағалау.
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

loadEnv(path.join(__dirname, '.env'));

const express = require('express');
const bcrypt = require('bcryptjs');
const multer = require('multer');
const DB = require('./db');
const AI = require('./ai');
const SEED = require('./seed');

const PORT = Number(process.env.PORT) || 3000;
const DATA_DIR = path.resolve(process.env.DATA_DIR || path.join(__dirname, 'data'));
const UPLOADS = path.join(DATA_DIR, 'uploads');
const SESSION_DAYS = 14;
const MONTHS = ['Қыркүйек', 'Қазан', 'Қараша', 'Желтоқсан', 'Қаңтар', 'Ақпан', 'Наурыз', 'Сәуір', 'Мамыр'];
const BOOK_COLORS = ['#1C7385', '#6A4C93', '#B5651D', '#2E7D4F', '#8C2F39', '#3D5A99', '#C0841A', '#D0467A'];

fs.mkdirSync(UPLOADS, { recursive: true });
DB.init(path.join(DATA_DIR, 'db.json'));
seed();

/* ---------- Көмекші функциялар ---------- */
function loadEnv(file) {
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
}
function seed() {
  const d = DB.d;
  if (!d.books.length) {
    d.books.push({
      id: DB.id(), title: SEED.title, author: SEED.author, color: SEED.color, parts: SEED.parts,
      cover: null, ebook: null, ranges: null, texts: SEED.texts, tasks: SEED.tasks, gen: null,
      createdBy: 'system', createdAt: new Date().toISOString(),
    });
    DB.save();
  }
}
const now = () => new Date().toISOString();
const clean = (v, max = 200) => String(v ?? '').trim().slice(0, max);
const err = (res, code, msg) => res.status(code).json({ error: msg });
function classCode() {
  const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let c;
  do { c = Array.from(crypto.randomBytes(6), b => A[b % A.length]).join(''); }
  while (DB.d.classes.some(k => k.code === c));
  return c;
}
function tempPassword() {
  const A = 'abcdefghjkmnpqrstuvwxyz23456789';
  return Array.from(crypto.randomBytes(8), b => A[b % A.length]).join('');
}
function publicUser(u) {
  if (!u) return null;
  const c = u.classId && DB.d.classes.find(k => k.id === u.classId);
  return { id: u.id, role: u.role, name: u.name, login: u.login, status: u.status, classId: u.classId || null, className: c ? c.name : null, createdAt: u.createdAt };
}
function cookies(req) {
  const out = {};
  for (const p of (req.headers.cookie || '').split(';')) {
    const i = p.indexOf('=');
    if (i > 0) out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim());
  }
  return out;
}
function startSession(res, user) {
  const token = crypto.randomBytes(32).toString('hex');
  DB.d.sessions[token] = { uid: user.id, exp: Date.now() + SESSION_DAYS * 864e5 };
  for (const [t, s] of Object.entries(DB.d.sessions)) if (s.exp < Date.now()) delete DB.d.sessions[t];
  DB.save();
  const secure = process.env.COOKIE_SECURE === '1' ? '; Secure' : '';
  res.setHeader('Set-Cookie', `sid=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${SESSION_DAYS * 86400}${secure}`);
}
function dropSessions(uid) {
  for (const [t, s] of Object.entries(DB.d.sessions)) if (s.uid === uid) delete DB.d.sessions[t];
}

/* ---------- Монета, баға ---------- */
const colorOf = p => (!p || !p.done ? null : p.score >= 0.85 ? 'g' : p.score >= 0.5 ? 'y' : 'r');
const starsOf = p => (!p || !p.done ? 0 : p.score >= 0.85 ? 3 : p.score >= 0.5 ? 2 : 1);
function coinsOf(uid) {
  const pr = DB.d.progress[uid] || {};
  let c = 0;
  for (const [bid, arr] of Object.entries(pr)) {
    const b = DB.d.books.find(x => x.id === bid);
    if (!b) continue;
    let all = true;
    b.parts.forEach((_, i) => {
      const p = arr[i];
      if (p && p.done) c += 10 + (starsOf(p) === 3 ? 5 : 0) + (p.jig ? 5 : 0);
      else all = false;
    });
    if (all) c += 50;
  }
  return c;
}
function gradeCell(uid, bid, i) {
  const p = ((DB.d.progress[uid] || {})[bid] || [])[i] || null;
  const auto = colorOf(p);
  const ov = DB.d.overrides[`${uid}|${bid}|${i}`];
  return { color: ov !== undefined ? ov : auto, auto, override: ov !== undefined, score: p && p.done ? Math.round(p.score * 100) : null, at: p ? p.at : null, comic: p ? p.comic || '' : '', open: p ? p.open || '' : '' };
}

/* ---------- Кітап ---------- */
function bookSummary(b) {
  return {
    id: b.id, title: b.title, author: b.author, color: b.color, parts: b.parts, cover: b.cover,
    ebook: b.ebook ? { kind: b.ebook.kind, pages: b.ebook.pages || null, name: b.ebook.name, file: b.ebook.file } : null,
    ranges: b.ranges || null,
    hasText: b.parts.map((_, i) => !!(b.texts && b.texts[i])),
    tasks: b.tasks || [],
    gen: b.gen || null, createdBy: b.createdBy, createdAt: b.createdAt,
  };
}
const bookFull = b => Object.assign(bookSummary(b), { texts: b.texts || {} });
const canEditBook = (u, b) => u.role === 'admin' || b.createdBy === u.id;

/* ---------- Сынып ---------- */
const canClass = (u, c) => !!c && (u.role === 'admin' || c.teacherId === u.id);
function classInfo(c) {
  const t = DB.d.users.find(u => u.id === c.teacherId);
  return {
    id: c.id, name: c.name, code: c.code, teacherId: c.teacherId, teacherName: t ? t.name : '—',
    plan: c.plan, openIdx: c.openIdx,
    studentCount: DB.d.users.filter(u => u.role === 'student' && u.classId === c.id).length,
  };
}

/* ---------- AI генерация ---------- */
const genStop = new Set();
async function runGeneration(book) {
  const n = book.parts.length;
  book.gen = { running: true, done: 0, total: n, ok: 0, skipped: 0, msg: 'Басталды', at: now() };
  book.tasks = book.tasks || [];
  DB.save();
  for (let i = 0; i < n; i++) {
    if (genStop.has(book.id)) { book.gen.msg = 'Тоқтатылды'; break; }
    const text = (book.texts && book.texts[i]) || '';
    book.gen.msg = `${i + 1} / ${n} бөлім дайындалып жатыр`;
    DB.save();
    if (text.length < 150) { book.gen.skipped++; book.gen.done++; continue; }
    try {
      const t = await AI.generatePart(book, i, text);
      if (t) { book.tasks[i] = t; book.gen.ok++; } else book.gen.skipped++;
    } catch (e) {
      console.error('[AI]', e.message);
      book.gen.skipped++;
      book.gen.lastError = e.message.slice(0, 200);
      if (e.status === 401 || e.status === 403) { book.gen.msg = 'AI кілті жарамсыз'; break; }
    }
    book.gen.done++;
    DB.save();
  }
  genStop.delete(book.id);
  book.gen.running = false;
  if (!/кілті|Тоқтатылды/.test(book.gen.msg)) book.gen.msg = `${book.gen.ok} бөлім дайын` + (book.gen.skipped ? `, ${book.gen.skipped} бөлім дайындалмады` : '');
  book.gen.at = now();
  DB.save();
}
function maybeGenerate(book) {
  if (AI.enabled() && book.parts.some((_, i) => book.texts && (book.texts[i] || '').length >= 150) && !(book.gen && book.gen.running)) {
    runGeneration(book).catch(e => console.error(e));
  }
}

/* ---------- Файл жүктеу ---------- */
const ALLOWED = {
  cover: { 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp' },
  ebook: { 'application/pdf': '.pdf', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document': '.docx', 'text/plain': '.txt' },
};
const upload = multer({
  storage: multer.diskStorage({
    destination: UPLOADS,
    filename: (req, f, cb) => cb(null, crypto.randomBytes(16).toString('hex') + extFor(f)),
  }),
  limits: { fileSize: 60 * 1024 * 1024, files: 2, fieldSize: 20 * 1024 * 1024 },
  fileFilter: (req, f, cb) => cb(null, !!extFor(f)),
});
function extFor(f) {
  const map = ALLOWED[f.fieldname] || {};
  if (map[f.mimetype]) return map[f.mimetype];
  const e = path.extname(f.originalname || '').toLowerCase();
  if (f.fieldname === 'ebook' && ['.pdf', '.docx', '.txt'].includes(e)) return e;
  if (f.fieldname === 'cover' && ['.jpg', '.jpeg', '.png', '.webp'].includes(e)) return e === '.jpeg' ? '.jpg' : e;
  return '';
}
function removeFile(name) {
  if (name && /^[a-f0-9]{32}\.\w+$/.test(name)) fs.rm(path.join(UPLOADS, name), { force: true }, () => {});
}
function saveDataUrl(dataUrl) {
  const m = /^data:image\/(jpeg|png);base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl || '');
  if (!m) return null;
  const buf = Buffer.from(m[2], 'base64');
  if (buf.length > 4 * 1024 * 1024) return null;
  const name = crypto.randomBytes(16).toString('hex') + (m[1] === 'png' ? '.png' : '.jpg');
  fs.writeFileSync(path.join(UPLOADS, name), buf);
  return name;
}
function parseMeta(req) {
  try { return JSON.parse(req.body.meta || '{}'); } catch (e) { return {}; }
}
function cleanTexts(t, n) {
  const out = {};
  if (t && typeof t === 'object') for (let i = 0; i < n; i++) if (t[i]) out[i] = String(t[i]).slice(0, 200000);
  return out;
}
function cleanRanges(r, n, pages) {
  if (!Array.isArray(r) || r.length !== n) return null;
  return r.map(x => {
    const a = Math.max(1, Math.min(pages || 9999, Number(x && x[0]) || 1));
    const b = Math.max(a, Math.min(pages || 9999, Number(x && x[1]) || a));
    return [a, b];
  });
}
const cleanParts = p => (Array.isArray(p) ? p : []).map(x => clean(x, 120)).filter(Boolean).slice(0, 40);

/* ---------- Қосымша ---------- */
const app = express();
app.disable('x-powered-by');
app.set('trust proxy', process.env.TRUST_PROXY === '1');
app.use((req, res, next) => {
  res.set('X-Content-Type-Options', 'nosniff');
  res.set('X-Frame-Options', 'SAMEORIGIN');
  res.set('Referrer-Policy', 'same-origin');
  next();
});
app.use(express.json({ limit: '12mb' }));

function auth(req, res, next) {
  const t = cookies(req).sid;
  const s = t && DB.d.sessions[t];
  if (!s || s.exp < Date.now()) return err(res, 401, 'Жүйеге қайта кіріңіз');
  const u = DB.d.users.find(x => x.id === s.uid);
  if (!u || u.status !== 'active') return err(res, 401, 'Жүйеге қайта кіріңіз');
  req.user = u;
  req.sid = t;
  next();
}
const role = (...r) => (req, res, next) => (r.includes(req.user.role) ? next() : err(res, 403, 'Бұл әрекетке рұқсат жоқ'));
const staff = role('teacher', 'admin');

// Кіруге тым көп әрекет жасауды шектеу
const tries = new Map();
function limited(req) {
  const k = req.ip;
  const r = tries.get(k) || { n: 0, t: Date.now() };
  if (Date.now() - r.t > 10 * 60e3) { r.n = 0; r.t = Date.now(); }
  r.n++;
  tries.set(k, r);
  return r.n > 20;
}

/* ---------- Тіркелу және кіру ---------- */
app.get('/api/status', (req, res) => {
  res.json({ needsSetup: DB.d.users.length === 0, ai: AI.enabled(), months: MONTHS });
});

function validCreds(b) {
  const name = clean(b.name, 80), login = clean(b.login, 32).toLowerCase(), password = String(b.password || '');
  if (name.length < 2) return { e: 'Аты-жөніңізді жазыңыз' };
  if (!/^[a-z0-9_.-]{3,32}$/.test(login)) return { e: 'Логин 3–32 таңбадан тұрады: латын әріптері, сандар, нүкте, сызықша' };
  if (password.length < 6) return { e: 'Құпия сөз кемінде 6 таңба болуы керек' };
  if (DB.d.users.some(u => u.login === login)) return { e: 'Бұл логин бос емес. Басқа логин таңдаңыз' };
  return { name, login, password };
}

app.post('/api/setup', (req, res) => {
  if (DB.d.users.length) return err(res, 400, 'Әкімші бұрын тіркелген');
  const v = validCreds(req.body || {});
  if (v.e) return err(res, 400, v.e);
  const u = { id: DB.id(), role: 'admin', name: v.name, login: v.login, pass: bcrypt.hashSync(v.password, 10), status: 'active', classId: null, createdAt: now() };
  DB.d.users.push(u);
  startSession(res, u);
  res.json({ user: publicUser(u) });
});

app.post('/api/register', (req, res) => {
  if (limited(req)) return err(res, 429, 'Тым көп әрекет. 10 минуттан кейін қайталаңыз');
  if (!DB.d.users.length) return err(res, 400, 'Алдымен әкімші тіркелуі керек');
  const b = req.body || {};
  const r = b.role === 'teacher' ? 'teacher' : b.role === 'student' ? 'student' : null;
  if (!r) return err(res, 400, 'Рөлді таңдаңыз');
  const v = validCreds(b);
  if (v.e) return err(res, 400, v.e);
  let classId = null;
  if (r === 'student') {
    const code = clean(b.classCode, 12).toUpperCase();
    const c = DB.d.classes.find(k => k.code === code);
    if (!c) return err(res, 400, 'Сынып коды табылмады. Кодты мұғаліміңнен сұра');
    classId = c.id;
  }
  const status = r === 'teacher' && process.env.AUTO_APPROVE_TEACHERS !== '1' ? 'pending' : 'active';
  const u = { id: DB.id(), role: r, name: v.name, login: v.login, pass: bcrypt.hashSync(v.password, 10), status, classId, createdAt: now() };
  DB.d.users.push(u);
  if (status === 'active') startSession(res, u); else DB.save();
  res.json({ user: publicUser(u), pending: status === 'pending' });
});

app.post('/api/login', (req, res) => {
  if (limited(req)) return err(res, 429, 'Тым көп әрекет. 10 минуттан кейін қайталаңыз');
  const login = clean((req.body || {}).login, 32).toLowerCase();
  const u = DB.d.users.find(x => x.login === login);
  if (!u || !bcrypt.compareSync(String((req.body || {}).password || ''), u.pass)) return err(res, 401, 'Логин немесе құпия сөз қате');
  if (u.status === 'pending') return err(res, 403, 'Тіркелуіңіз әкімшінің растауын күтіп тұр');
  if (u.status === 'blocked') return err(res, 403, 'Аккаунт бұғатталған. Әкімшіге хабарласыңыз');
  startSession(res, u);
  res.json({ user: publicUser(u) });
});

app.post('/api/logout', (req, res) => {
  const t = cookies(req).sid;
  if (t) { delete DB.d.sessions[t]; DB.save(); }
  res.setHeader('Set-Cookie', 'sid=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0');
  res.json({ ok: true });
});

app.get('/api/me', auth, (req, res) => res.json({ user: publicUser(req.user) }));

app.post('/api/me/password', auth, (req, res) => {
  const b = req.body || {};
  if (!bcrypt.compareSync(String(b.old || ''), req.user.pass)) return err(res, 400, 'Қазіргі құпия сөз қате');
  if (String(b.password || '').length < 6) return err(res, 400, 'Жаңа құпия сөз кемінде 6 таңба болуы керек');
  req.user.pass = bcrypt.hashSync(String(b.password), 10);
  DB.save();
  res.json({ ok: true });
});

/* ---------- Әкімші ---------- */
app.get('/api/admin/users', auth, role('admin'), (req, res) => {
  res.json({ users: DB.d.users.map(u => Object.assign(publicUser(u), { coins: u.role === 'student' ? coinsOf(u.id) : null })) });
});

app.post('/api/admin/users/:id', auth, role('admin'), (req, res) => {
  const u = DB.d.users.find(x => x.id === req.params.id);
  if (!u) return err(res, 404, 'Пайдаланушы табылмады');
  const a = (req.body || {}).action;
  if (u.id === req.user.id && ['block', 'role'].includes(a)) return err(res, 400, 'Өз аккаунтыңызды өзгерте алмайсыз');
  let extra = {};
  if (a === 'approve' || a === 'unblock') u.status = 'active';
  else if (a === 'block') { u.status = 'blocked'; dropSessions(u.id); }
  else if (a === 'role') {
    const r = req.body.value;
    if (u.role === 'student' || !['teacher', 'admin'].includes(r)) return err(res, 400, 'Бұл рөлді өзгертуге болмайды');
    u.role = r;
  } else if (a === 'reset') {
    const p = tempPassword();
    u.pass = bcrypt.hashSync(p, 10);
    dropSessions(u.id);
    extra = { password: p };
  } else if (a === 'move') {
    if (u.role !== 'student') return err(res, 400, 'Тек оқушыны басқа сыныпқа ауыстыруға болады');
    const c = DB.d.classes.find(k => k.id === req.body.value);
    if (!c) return err(res, 400, 'Сынып табылмады');
    u.classId = c.id;
  } else return err(res, 400, 'Белгісіз әрекет');
  DB.save();
  res.json(Object.assign({ user: publicUser(u) }, extra));
});

app.delete('/api/admin/users/:id', auth, role('admin'), (req, res) => {
  const u = DB.d.users.find(x => x.id === req.params.id);
  if (!u) return err(res, 404, 'Пайдаланушы табылмады');
  if (u.id === req.user.id) return err(res, 400, 'Өз аккаунтыңызды өшіре алмайсыз');
  if (u.role === 'teacher' && DB.d.classes.some(c => c.teacherId === u.id)) return err(res, 400, 'Алдымен бұл мұғалімнің сыныптарын басқа мұғалімге беріңіз');
  dropSessions(u.id);
  delete DB.d.progress[u.id];
  for (const k of Object.keys(DB.d.overrides)) if (k.startsWith(u.id + '|')) delete DB.d.overrides[k];
  DB.d.drawings = DB.d.drawings.filter(d => { if (d.studentId === u.id) { removeFile(d.file); return false; } return true; });
  DB.d.users = DB.d.users.filter(x => x.id !== u.id);
  DB.save();
  res.json({ ok: true });
});

app.get('/api/admin/overview', auth, role('admin'), (req, res) => {
  const d = DB.d;
  const by = r => d.users.filter(u => u.role === r);
  let partsDone = 0;
  for (const pr of Object.values(d.progress)) for (const arr of Object.values(pr)) partsDone += arr.filter(p => p && p.done).length;
  const classes = d.classes.map(c => {
    const st = by('student').filter(u => u.classId === c.id);
    const cnt = { g: 0, y: 0, r: 0 };
    for (const s of st) for (const [bid, arr] of Object.entries(d.progress[s.id] || {})) arr.forEach((p, i) => { const col = gradeCell(s.id, bid, i).color; if (col) cnt[col]++; });
    return Object.assign(classInfo(c), { colors: cnt, openBook: c.openIdx >= 0 && c.plan[c.openIdx] ? (d.books.find(b => b.id === c.plan[c.openIdx]) || {}).title || null : null });
  });
  res.json({
    counts: {
      students: by('student').length, teachers: by('teacher').filter(u => u.status === 'active').length,
      pending: d.users.filter(u => u.status === 'pending').length, admins: by('admin').length,
      classes: d.classes.length, books: d.books.length, partsDone, drawings: d.drawings.length,
    },
    classes, ai: AI.enabled(), model: AI.enabled() ? AI.model() : null,
  });
});

/* ---------- Сыныптар ---------- */
app.get('/api/classes', auth, staff, (req, res) => {
  const list = DB.d.classes.filter(c => canClass(req.user, c)).map(classInfo);
  const teachers = req.user.role === 'admin' ? DB.d.users.filter(u => (u.role === 'teacher' || u.role === 'admin') && u.status === 'active').map(u => ({ id: u.id, name: u.name })) : null;
  res.json({ classes: list, teachers, months: MONTHS });
});

app.post('/api/classes', auth, staff, (req, res) => {
  const name = clean((req.body || {}).name, 40);
  if (!name) return err(res, 400, 'Сынып атауын жазыңыз, мысалы: 4 «А»');
  let teacherId = req.user.id;
  if (req.user.role === 'admin' && req.body.teacherId) {
    const t = DB.d.users.find(u => u.id === req.body.teacherId && (u.role === 'teacher' || u.role === 'admin'));
    if (!t) return err(res, 400, 'Мұғалім табылмады');
    teacherId = t.id;
  }
  const c = { id: DB.id(), name, code: classCode(), teacherId, plan: Array(MONTHS.length).fill(''), openIdx: -1, createdAt: now() };
  DB.d.classes.push(c);
  DB.save();
  res.json({ class: classInfo(c) });
});

app.put('/api/classes/:id', auth, staff, (req, res) => {
  const c = DB.d.classes.find(k => k.id === req.params.id);
  if (!canClass(req.user, c)) return err(res, 404, 'Сынып табылмады');
  const b = req.body || {};
  if (b.name !== undefined) { const n = clean(b.name, 40); if (n) c.name = n; }
  if (Array.isArray(b.plan)) c.plan = MONTHS.map((_, i) => (DB.d.books.some(x => x.id === b.plan[i]) ? b.plan[i] : ''));
  if (b.openIdx !== undefined) {
    const i = Number(b.openIdx);
    if (!(i >= -1 && i < MONTHS.length)) return err(res, 400, 'Ай дұрыс емес');
    if (i >= 0 && !c.plan[i]) return err(res, 400, 'Алдымен осы айға кітап таңдаңыз');
    c.openIdx = i;
  }
  if (b.teacherId && req.user.role === 'admin') {
    const t = DB.d.users.find(u => u.id === b.teacherId && (u.role === 'teacher' || u.role === 'admin'));
    if (t) c.teacherId = t.id;
  }
  if (b.newCode) c.code = classCode();
  DB.save();
  res.json({ class: classInfo(c) });
});

app.delete('/api/classes/:id', auth, staff, (req, res) => {
  const c = DB.d.classes.find(k => k.id === req.params.id);
  if (!canClass(req.user, c)) return err(res, 404, 'Сынып табылмады');
  if (DB.d.users.some(u => u.role === 'student' && u.classId === c.id)) return err(res, 400, 'Сыныпта оқушылар бар. Алдымен оларды басқа сыныпқа ауыстырыңыз');
  DB.d.classes = DB.d.classes.filter(k => k.id !== c.id);
  DB.save();
  res.json({ ok: true });
});

app.get('/api/classes/:id/students', auth, staff, (req, res) => {
  const c = DB.d.classes.find(k => k.id === req.params.id);
  if (!canClass(req.user, c)) return err(res, 404, 'Сынып табылмады');
  const list = DB.d.users.filter(u => u.role === 'student' && u.classId === c.id).map(u => {
    let done = 0;
    for (const arr of Object.values(DB.d.progress[u.id] || {})) done += arr.filter(p => p && p.done).length;
    return Object.assign(publicUser(u), { coins: coinsOf(u.id), partsDone: done, drawings: DB.d.drawings.filter(x => x.studentId === u.id).length });
  });
  res.json({ students: list });
});

app.post('/api/classes/:id/students/:sid/reset', auth, staff, (req, res) => {
  const c = DB.d.classes.find(k => k.id === req.params.id);
  const u = DB.d.users.find(x => x.id === req.params.sid && x.role === 'student');
  if (!canClass(req.user, c) || !u || u.classId !== c.id) return err(res, 404, 'Оқушы табылмады');
  const p = tempPassword();
  u.pass = bcrypt.hashSync(p, 10);
  dropSessions(u.id);
  DB.save();
  res.json({ password: p });
});

app.get('/api/classes/:id/grades', auth, staff, (req, res) => {
  const c = DB.d.classes.find(k => k.id === req.params.id);
  if (!canClass(req.user, c)) return err(res, 404, 'Сынып табылмады');
  const b = DB.d.books.find(x => x.id === req.query.bookId);
  if (!b) return err(res, 404, 'Кітап табылмады');
  const students = DB.d.users.filter(u => u.role === 'student' && u.classId === c.id)
    .sort((x, y) => x.name.localeCompare(y.name, 'kk'))
    .map(u => ({ id: u.id, name: u.name, cells: b.parts.map((_, i) => gradeCell(u.id, b.id, i)) }));
  const ids = new Set(students.map(s => s.id));
  const drawings = DB.d.drawings.filter(d => d.bookId === b.id && ids.has(d.studentId)).length;
  res.json({ book: { id: b.id, title: b.title, parts: b.parts }, students, drawings });
});

app.put('/api/classes/:id/grades', auth, staff, (req, res) => {
  const c = DB.d.classes.find(k => k.id === req.params.id);
  if (!canClass(req.user, c)) return err(res, 404, 'Сынып табылмады');
  const { studentId, bookId, part, color } = req.body || {};
  const u = DB.d.users.find(x => x.id === studentId && x.classId === c.id);
  const b = DB.d.books.find(x => x.id === bookId);
  if (!u || !b || !(part >= 0 && part < b.parts.length)) return err(res, 400, 'Деректер дұрыс емес');
  const key = `${u.id}|${b.id}|${part}`;
  if (color === 'auto') delete DB.d.overrides[key];
  else if (['r', 'y', 'g', null].includes(color)) DB.d.overrides[key] = color;
  else return err(res, 400, 'Түс дұрыс емес');
  DB.save();
  res.json({ cell: gradeCell(u.id, b.id, part) });
});

app.get('/api/classes/:id/export.csv', auth, staff, (req, res) => {
  const c = DB.d.classes.find(k => k.id === req.params.id);
  if (!canClass(req.user, c)) return err(res, 404, 'Сынып табылмады');
  const T = { g: 'Толық меңгерді', y: 'Жартылай түсінді', r: 'Оқымады немесе түсінбеді', null: 'Орындамады' };
  const books = c.plan.map((id, i) => ({ id, i })).filter(x => x.id && x.i <= c.openIdx).map(x => DB.d.books.find(b => b.id === x.id)).filter(Boolean);
  const q = v => '"' + String(v ?? '').replace(/"/g, '""') + '"';
  const rows = [['Оқушы', 'Логин', 'Кітап', 'Бөлім', 'Баға', 'Ұпай %', 'Күні', 'Монета'].map(q).join(';')];
  for (const u of DB.d.users.filter(x => x.role === 'student' && x.classId === c.id)) {
    const coins = coinsOf(u.id);
    for (const b of books) b.parts.forEach((p, i) => {
      const g = gradeCell(u.id, b.id, i);
      rows.push([u.name, u.login, b.title, `${i + 1}. ${p}`, T[g.color], g.score ?? '', g.at ? g.at.slice(0, 10) : '', coins].map(q).join(';'));
    });
  }
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="grades-${encodeURIComponent(c.name)}.csv"`);
  res.send('﻿' + rows.join('\r\n'));
});

/* ---------- Кітаптар ---------- */
app.get('/api/books', auth, staff, (req, res) => res.json({ books: DB.d.books.map(bookSummary), ai: AI.enabled() }));

app.get('/api/books/:id', auth, (req, res) => {
  const b = DB.d.books.find(x => x.id === req.params.id);
  if (!b) return err(res, 404, 'Кітап табылмады');
  if (req.user.role === 'student') {
    const c = DB.d.classes.find(k => k.id === req.user.classId);
    const i = c ? c.plan.indexOf(b.id) : -1;
    if (!c || i < 0 || i > c.openIdx) return err(res, 403, 'Бұл кітап әлі ашылмаған');
  }
  res.json({ book: bookFull(b) });
});

app.post('/api/books', auth, staff, upload.fields([{ name: 'cover', maxCount: 1 }, { name: 'ebook', maxCount: 1 }]), (req, res) => {
  const m = parseMeta(req);
  const title = clean(m.title, 120);
  if (!title) return err(res, 400, 'Кітаптың атауын жазыңыз');
  const parts = cleanParts(m.parts);
  const b = {
    id: DB.id(), title, author: clean(m.author, 120), color: BOOK_COLORS[DB.d.books.length % BOOK_COLORS.length],
    parts: parts.length ? parts : ['1-бөлім', '2-бөлім', '3-бөлім'], cover: null, ebook: null, ranges: null, texts: {}, tasks: [], gen: null,
    createdBy: req.user.id, createdAt: now(),
  };
  const f = req.files || {};
  if (f.cover) b.cover = f.cover[0].filename;
  if (f.ebook) {
    const e = f.ebook[0];
    const kind = e.filename.endsWith('.pdf') ? 'pdf' : 'text';
    b.ebook = { file: e.filename, kind, name: clean(e.originalname, 200), pages: kind === 'pdf' ? Number(m.pages) || null : null };
    if (kind === 'pdf') b.ranges = cleanRanges(m.ranges, b.parts.length, b.ebook.pages);
  }
  b.texts = cleanTexts(m.texts, b.parts.length);
  DB.d.books.push(b);
  DB.save();
  maybeGenerate(b);
  res.json({ book: bookSummary(b) });
});

app.put('/api/books/:id', auth, staff, (req, res) => {
  const b = DB.d.books.find(x => x.id === req.params.id);
  if (!b) return err(res, 404, 'Кітап табылмады');
  if (!canEditBook(req.user, b)) return err(res, 403, 'Бұл кітапты тек оны қосқан мұғалім немесе әкімші өзгерте алады');
  const m = req.body || {};
  if (m.title !== undefined) { const t = clean(m.title, 120); if (t) b.title = t; }
  if (m.author !== undefined) b.author = clean(m.author, 120);
  if (m.ranges !== undefined && b.ebook && b.ebook.kind === 'pdf') b.ranges = cleanRanges(m.ranges, b.parts.length, b.ebook.pages);
  if (m.texts !== undefined) b.texts = cleanTexts(m.texts, b.parts.length);
  if (Array.isArray(m.tasks)) b.tasks = b.parts.map((_, i) => (m.tasks[i] ? AI.normalize(m.tasks[i]) : null));
  DB.save();
  res.json({ book: bookSummary(b) });
});

app.post('/api/books/:id/cover', auth, staff, upload.single('cover'), (req, res) => {
  const b = DB.d.books.find(x => x.id === req.params.id);
  if (!b) return err(res, 404, 'Кітап табылмады');
  if (!req.file) return err(res, 400, 'JPG, PNG немесе WEBP сурет таңдаңыз');
  if (!canEditBook(req.user, b)) { removeFile(req.file.filename); return err(res, 403, 'Бұл кітапты өзгертуге рұқсат жоқ'); }
  removeFile(b.cover);
  b.cover = req.file.filename;
  DB.save();
  res.json({ book: bookSummary(b) });
});

app.post('/api/books/:id/ebook', auth, staff, upload.single('ebook'), (req, res) => {
  const b = DB.d.books.find(x => x.id === req.params.id);
  if (!b) return err(res, 404, 'Кітап табылмады');
  if (!req.file) return err(res, 400, 'PDF, Word (.docx) немесе .txt файлын таңдаңыз');
  if (!canEditBook(req.user, b)) { removeFile(req.file.filename); return err(res, 403, 'Бұл кітапты өзгертуге рұқсат жоқ'); }
  const m = parseMeta(req);
  if (b.ebook) removeFile(b.ebook.file);
  const kind = req.file.filename.endsWith('.pdf') ? 'pdf' : 'text';
  b.ebook = { file: req.file.filename, kind, name: clean(req.file.originalname, 200), pages: kind === 'pdf' ? Number(m.pages) || null : null };
  b.ranges = kind === 'pdf' ? cleanRanges(m.ranges, b.parts.length, b.ebook.pages) : null;
  b.texts = cleanTexts(m.texts, b.parts.length);
  b.tasks = [];
  b.gen = null;
  DB.save();
  maybeGenerate(b);
  res.json({ book: bookSummary(b) });
});

app.post('/api/books/:id/generate', auth, staff, (req, res) => {
  const b = DB.d.books.find(x => x.id === req.params.id);
  if (!b) return err(res, 404, 'Кітап табылмады');
  if (!AI.enabled()) return err(res, 400, 'AI кілті орнатылмаған. Әкімші .env файлына ANTHROPIC_API_KEY жазуы керек');
  if (b.gen && b.gen.running) return err(res, 400, 'Тапсырмалар дайындалып жатыр');
  if (!b.parts.some((_, i) => (b.texts && b.texts[i] || '').length >= 150)) return err(res, 400, 'Кітаптың мәтіні жоқ. Мәтіні бар PDF, Word немесе TXT файлын жүктеңіз');
  runGeneration(b).catch(e => console.error(e));
  res.json({ book: bookSummary(b) });
});

app.post('/api/books/:id/generate/stop', auth, staff, (req, res) => {
  genStop.add(req.params.id);
  res.json({ ok: true });
});

app.delete('/api/books/:id', auth, staff, (req, res) => {
  const b = DB.d.books.find(x => x.id === req.params.id);
  if (!b) return err(res, 404, 'Кітап табылмады');
  if (!canEditBook(req.user, b)) return err(res, 403, 'Бұл кітапты тек оны қосқан мұғалім немесе әкімші өшіре алады');
  if (DB.d.classes.some(c => c.plan.includes(b.id))) return err(res, 400, 'Бұл кітап бір сыныптың жоспарында тұр. Алдымен жоспардан алып тастаңыз');
  removeFile(b.cover);
  if (b.ebook) removeFile(b.ebook.file);
  DB.d.books = DB.d.books.filter(x => x.id !== b.id);
  DB.save();
  res.json({ ok: true });
});

/* ---------- Оқушы ---------- */
app.get('/api/student/home', auth, role('student'), (req, res) => {
  const u = req.user;
  const c = DB.d.classes.find(k => k.id === u.classId);
  const books = {};
  const plan = c ? c.plan.map((id, i) => {
    if (!id) return { month: i, bookId: null, state: 'empty' };
    const b = DB.d.books.find(x => x.id === id);
    if (!b) return { month: i, bookId: null, state: 'empty' };
    const state = i < c.openIdx ? 'done' : i === c.openIdx ? 'open' : 'locked';
    books[b.id] = state === 'locked' ? { id: b.id, title: b.title, author: b.author, color: b.color, cover: b.cover, parts: b.parts } : bookFull(b);
    return { month: i, bookId: b.id, state };
  }) : [];
  res.json({ user: publicUser(u), plan, months: MONTHS, books, progress: DB.d.progress[u.id] || {}, coins: coinsOf(u.id) });
});

app.post('/api/student/complete', auth, role('student'), (req, res) => {
  const u = req.user;
  const m = req.body || {};
  const c = DB.d.classes.find(k => k.id === u.classId);
  const b = DB.d.books.find(x => x.id === m.bookId);
  const idx = c && b ? c.plan.indexOf(b.id) : -1;
  if (!c || !b || idx < 0 || idx > c.openIdx) return err(res, 403, 'Бұл кітап әлі ашылмаған');
  const part = Number(m.part);
  if (!(part >= 0 && part < b.parts.length)) return err(res, 400, 'Бөлім дұрыс емес');
  const pr = (DB.d.progress[u.id] = DB.d.progress[u.id] || {});
  const arr = (pr[b.id] = pr[b.id] || []);
  if (part > 0 && !(arr[part - 1] && arr[part - 1].done)) return err(res, 400, 'Алдымен алдыңғы бөлімді аяқта');
  const pair = v => (Array.isArray(v) ? [Math.max(0, Number(v[0]) || 0), Math.max(0, Number(v[1]) || 0)] : [0, 0]);
  const q = pair(m.quiz), g = pair(m.game);
  q[0] = Math.min(q[0], q[1]); g[0] = Math.min(g[0], g[1]);
  const tot = q[1] + g[1];
  const score = tot ? (q[0] + g[0]) / tot : 0.6;
  const prev = arr[part];
  let file = null;
  if (m.drawing && m.drawing.img) {
    file = saveDataUrl(m.drawing.img);
    if (!file) return err(res, 400, 'Суретті сақтау мүмкін болмады. Кішірек сурет жүктеп көр');
    DB.d.drawings.push({ id: DB.id(), studentId: u.id, classId: c.id, bookId: b.id, part, file, cap: clean(m.drawing.cap, 300), prompt: clean(m.drawing.prompt, 300), at: now() });
  }
  arr[part] = {
    done: true, score: prev && prev.done ? Math.max(prev.score, score) : score,
    quiz: q, game: g, jig: !!m.jig || !!(prev && prev.jig), comic: clean(m.comic, 300), open: clean(m.open, 1000),
    at: now(), attempts: (prev && prev.attempts || 0) + 1,
  };
  DB.save();
  res.json({ progress: pr, coins: coinsOf(u.id), score: arr[part].score });
});

/* ---------- Суреттер ---------- */
app.get('/api/drawings', auth, staff, (req, res) => {
  const classes = DB.d.classes.filter(c => canClass(req.user, c) && (!req.query.classId || c.id === req.query.classId));
  const ids = new Set(classes.map(c => c.id));
  const list = DB.d.drawings.filter(d => ids.has(d.classId) && (!req.query.bookId || d.bookId === req.query.bookId))
    .sort((a, b) => (a.at < b.at ? 1 : -1))
    .map(d => {
      const u = DB.d.users.find(x => x.id === d.studentId);
      const b = DB.d.books.find(x => x.id === d.bookId);
      const c = DB.d.classes.find(x => x.id === d.classId);
      return Object.assign({}, d, { studentName: u ? u.name : '—', bookTitle: b ? b.title : '—', className: c ? c.name : '—' });
    });
  res.json({ drawings: list });
});

/* ---------- Файлдар ---------- */
app.get('/files/:name', auth, (req, res) => {
  const n = req.params.name;
  if (!/^[a-f0-9]{32}\.(jpg|png|webp|pdf|docx|txt)$/.test(n)) return res.status(404).end();
  res.sendFile(path.join(UPLOADS, n), { maxAge: '7d', headers: { 'Cache-Control': 'private, max-age=604800' } }, e => { if (e && !res.headersSent) res.status(404).end(); });
});

app.use('/api', (req, res) => err(res, 404, 'Мұндай сұраныс жоқ'));
app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'] }));
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

app.use((e, req, res, next) => {
  if (e && e.code === 'LIMIT_FILE_SIZE') return err(res, 400, 'Файл тым үлкен: 60 МБ-тан аспауы керек');
  console.error(e);
  err(res, 500, 'Серверде қате шықты');
});

const server = app.listen(PORT, () => {
  console.log(`«Оқырман мектеп» іске қосылды: http://localhost:${PORT}`);
  console.log(AI.enabled() ? `AI қосулы (${AI.model()})` : 'AI өшірулі: .env файлына ANTHROPIC_API_KEY жазыңыз');
});
function shutdown() { DB.flush(); server.close(() => process.exit(0)); setTimeout(() => process.exit(0), 2000); }
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
