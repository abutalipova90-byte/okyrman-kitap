/* «Оқырман мектеп»: мұғалім кабинеті және әкімші панелі */
const Staff = (() => {
  let tab = null, CL = [], TEACHERS = null, BOOKS = [], cls = store.get('cls', null), pollT = null;
  const TABS = {
    admin: [['overview', 'Шолу'], ['users', 'Пайдаланушылар'], ['classes', 'Сыныптар'], ['month', 'Айдың кітабы'], ['books', 'Кітаптар'], ['grades', 'Бағалау'], ['report', 'Ай есебі'], ['gallery', 'Шығармашылық жұмыстар'], ['account', 'Аккаунтым']],
    teacher: [['classes', 'Сыныптарым'], ['month', 'Айдың кітабы'], ['books', 'Кітаптар'], ['grades', 'Бағалау'], ['report', 'Ай есебі'], ['gallery', 'Шығармашылық жұмыстар'], ['account', 'Аккаунтым']],
  };
  const tabs = () => TABS[ME.role];
  const dot = c => `<span class="dot ${c || ''}" aria-hidden="true"></span>`;
  const fmtDate = s => (s ? new Date(s).toLocaleDateString('kk-KZ') : '—');
  const bookById = id => BOOKS.find(b => b.id === id);
  const curClass = () => CL.find(c => c.id === cls) || CL[0] || null;
  const canEditBook = b => ME.role === 'admin' || b.createdBy === ME.id;

  async function start(home) {
    if (home || !tab || !tabs().some(t => t[0] === tab)) tab = tabs()[0][0];
    await loadBase();
    render();
  }
  async function loadBase() {
    try {
      const [c, b] = await Promise.all([api('/api/classes'), api('/api/books')]);
      CL = c.classes; TEACHERS = c.teachers; BOOKS = b.books;
      if (!CL.some(k => k.id === cls)) cls = CL[0] ? CL[0].id : null;
    } catch (e) { toast(e.message); }
  }
  function renderTabs() {
    const n = $('#tabs');
    n.hidden = false;
    n.innerHTML = tabs().map(([k, t]) => `<button data-t="${k}" aria-current="${k === tab}">${t}</button>`).join('');
    $$('#tabs button').forEach(b => (b.onclick = async () => { tab = b.dataset.t; await loadBase(); render(); window.scrollTo(0, 0); }));
  }
  async function render() {
    clearTimeout(pollT);
    renderTabs();
    $('#main').innerHTML = '<p class="loading">Жүктеліп жатыр…</p>';
    try {
      const html = await V[tab]();
      $('#main').innerHTML = `<div class="view">${html}</div>`;
      (A[tab] || (() => {}))();
    } catch (e) { $('#main').innerHTML = `<div class="view"><p class="empty">${esc(e.message)}</p></div>`; }
  }
  function classPicker(id = 'cls', all = false) {
    if (!CL.length) return '';
    const c = curClass();
    return `<label style="max-width:320px">Сынып<select id="${id}">${all ? `<option value="">Барлық сыныптар</option>` : ''}${CL.map(k => `<option value="${k.id}" ${c && k.id === c.id ? 'selected' : ''}>${esc(k.name)}${ME.role === 'admin' ? ' · ' + esc(k.teacherName) : ''}</option>`).join('')}</select></label>`;
  }
  function bindClassPicker(id = 'cls') {
    const s = $('#' + id);
    if (s) s.onchange = () => { cls = s.value || cls; store.set('cls', cls); render(); };
  }
  const noClass = () => `<div class="card empty"><p>Әзірге сынып жоқ.</p><p class="small">Алдымен «${ME.role === 'admin' ? 'Сыныптар' : 'Сыныптарым'}» бөлімінде сынып ашыңыз.</p></div>`;

  const V = {}, A = {};

  /* ---------- Шолу (әкімші) ---------- */
  V.overview = async () => {
    const o = await api('/api/admin/overview');
    const k = o.counts;
    return `<div class="stack"><h1>Мектеп бойынша шолу</h1><p class="lead">Барлық сынып, мұғалім және оқушы деректері.</p></div>
    ${k.pending ? `<div class="okbox" style="border-color:var(--accent);background:var(--accent-soft)"><b>${k.pending} мұғалім</b> тіркелуді растауды күтіп тұр. <button class="btn sm" id="topending" style="margin-left:8px">Растау</button></div>` : ''}
    <div class="kpis">
      <div class="card kpi"><span class="small muted">Оқушылар</span><b>${k.students}</b></div>
      <div class="card kpi"><span class="small muted">Мұғалімдер</span><b>${k.teachers}</b></div>
      <div class="card kpi"><span class="small muted">Сыныптар</span><b>${k.classes}</b></div>
      <div class="card kpi"><span class="small muted">Кітаптар</span><b>${k.books}</b></div>
      <div class="card kpi"><span class="small muted">Орындалған бөлімдер</span><b>${k.partsDone}</b></div>
      <div class="card kpi"><span class="small muted">Суреттер</span><b>${k.drawings}</b></div>
    </div>
    <div class="card"><h3>AI</h3><p class="small">${o.ai ? `Қосулы. Модель: <b>${esc(o.model)}</b>` : 'Өшірулі. AI тапсырма дайындау үшін серверде .env файлына ANTHROPIC_API_KEY жазып, сайтты қайта іске қосыңыз.'}</p></div>
    <h2>Сыныптар</h2>
    ${o.classes.length ? `<div class="tablebox"><table><thead><tr><th>Сынып</th><th>Мұғалім</th><th class="c">Оқушы</th><th>Ашық кітап</th><th>Бағалар</th></tr></thead><tbody>
    ${o.classes.map(c => { const t = c.colors.g + c.colors.y + c.colors.r; return `<tr><td><b>${esc(c.name)}</b></td><td>${esc(c.teacherName)}</td><td class="c">${c.studentCount}</td><td>${esc(c.openBook || '—')}</td>
      <td style="min-width:180px">${t ? `<div class="bar3">${['g', 'y', 'r'].map(x => `<div style="width:${c.colors[x] / t * 100}%;background:var(--${x})"></div>`).join('')}</div><span class="small muted">${c.colors.g} жасыл · ${c.colors.y} сары · ${c.colors.r} қызыл</span>` : '<span class="small muted">Әлі баға жоқ</span>'}</td></tr>`; }).join('')}
    </tbody></table></div>` : '<p class="muted">Әзірге сынып жоқ.</p>'}`;
  };
  A.overview = () => { const b = $('#topending'); if (b) b.onclick = () => { usersFilter = 'pending'; tab = 'users'; render(); }; };

  /* ---------- Пайдаланушылар (әкімші) ---------- */
  let usersFilter = 'all', usersQ = '', lastReset = null;
  V.users = async () => {
    const { users } = await api('/api/admin/users');
    const F = { all: 'Барлығы', pending: 'Растауды күтетіндер', teacher: 'Мұғалімдер', student: 'Оқушылар', admin: 'Әкімшілер', blocked: 'Бұғатталғандар' };
    const q = usersQ.toLowerCase();
    const list = users.filter(u => (usersFilter === 'all' || u.role === usersFilter || u.status === usersFilter) && (!q || (u.name + ' ' + u.login).toLowerCase().includes(q)))
      .sort((a, b) => (a.status === 'pending' ? -1 : 0) - (b.status === 'pending' ? -1 : 0) || a.name.localeCompare(b.name, 'kk'));
    const ST = { active: 'Белсенді', pending: 'Растауды күтуде', blocked: 'Бұғатталған' };
    return `<div class="stack"><h1>Пайдаланушылар</h1><p class="lead">Мұғалімдерді растау, құпия сөзді жаңарту, оқушыны басқа сыныпқа ауыстыру.</p></div>
    <div class="toolbar"><label>Сүзгі<select id="uf">${Object.entries(F).map(([k, t]) => `<option value="${k}" ${k === usersFilter ? 'selected' : ''}>${t} (${users.filter(u => k === 'all' || u.role === k || u.status === k).length})</option>`).join('')}</select></label>
      <label>Іздеу<input id="uq" value="${esc(usersQ)}" placeholder="Аты немесе логин"></label></div>
    ${lastReset ? `<div class="okbox"><b>${esc(lastReset.name)}</b> үшін жаңа құпия сөз: <span class="pw">${esc(lastReset.password)}</span>. Оны пайдаланушыға беріңіз.</div>` : ''}
    <div class="tablebox"><table><thead><tr><th>Аты-жөні</th><th>Логин</th><th>Рөлі</th><th>Сыныбы</th><th>Күйі</th><th>Тіркелген</th><th>Әрекет</th></tr></thead><tbody>
    ${list.length ? list.map(u => `<tr><td><b>${esc(u.name)}</b>${u.id === ME.id ? ' <span class="small muted">(сіз)</span>' : ''}</td><td>${esc(u.login)}</td><td>${ROLE_NAME[u.role]}</td>
      <td>${u.role === 'student' ? `<select data-move="${u.id}" aria-label="${esc(u.name)} сыныбы" style="min-width:110px">${CL.map(c => `<option value="${c.id}" ${c.id === u.classId ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}${u.classId ? '' : '<option selected>—</option>'}</select>` : '—'}</td>
      <td><span class="status ${u.status}">${ST[u.status]}</span></td><td class="small">${fmtDate(u.createdAt)}</td>
      <td><div class="row">${u.status === 'pending' ? `<button class="btn sm" data-act="approve" data-id="${u.id}">Растау</button>` : ''}
        ${u.status === 'blocked' ? `<button class="btn sm alt" data-act="unblock" data-id="${u.id}">Ашу</button>` : ''}
        ${u.status === 'active' && u.id !== ME.id ? `<button class="btn sm alt" data-act="block" data-id="${u.id}">Бұғаттау</button>` : ''}
        <button class="btn sm alt" data-act="reset" data-id="${u.id}" data-name="${esc(u.name)}">Құпия сөз</button>
        ${u.role === 'teacher' && u.status === 'active' ? `<button class="btn sm alt" data-act="role" data-val="admin" data-id="${u.id}">Әкімші ету</button>` : ''}
        ${u.role === 'admin' && u.id !== ME.id ? `<button class="btn sm alt" data-act="role" data-val="teacher" data-id="${u.id}">Мұғалім ету</button>` : ''}
        ${u.id !== ME.id ? `<button class="btn sm danger" data-del="${u.id}" data-name="${esc(u.name)}">Өшіру</button>` : ''}</div></td></tr>`).join('') : '<tr><td colspan="7" class="empty">Ешкім табылмады</td></tr>'}
    </tbody></table></div>`;
  };
  A.users = () => {
    $('#uf').onchange = e => { usersFilter = e.target.value; lastReset = null; render(); };
    let t; $('#uq').oninput = e => { clearTimeout(t); t = setTimeout(() => { usersQ = e.target.value; render(); }, 350); };
    $$('[data-act]').forEach(b => (b.onclick = async () => {
      try {
        const r = await api('/api/admin/users/' + b.dataset.id, { method: 'POST', body: { action: b.dataset.act, value: b.dataset.val } });
        lastReset = r.password ? { name: b.dataset.name, password: r.password } : null;
        toast('Сақталды');
        render();
      } catch (e) { toast(e.message, 4000); }
    }));
    $$('[data-move]').forEach(s => (s.onchange = async () => {
      try { await api('/api/admin/users/' + s.dataset.move, { method: 'POST', body: { action: 'move', value: s.value } }); toast('Оқушы басқа сыныпқа ауыстырылды'); }
      catch (e) { toast(e.message, 4000); render(); }
    }));
    $$('[data-del]').forEach(b => (b.onclick = async () => {
      if (!confirm(`«${b.dataset.name}» аккаунтын өшіресіз бе? Оның барлық нәтижелері мен суреттері де өшеді.`)) return;
      try { await api('/api/admin/users/' + b.dataset.del, { method: 'DELETE' }); toast('Өшірілді'); await loadBase(); render(); }
      catch (e) { toast(e.message, 4000); }
    }));
  };

  /* ---------- Сыныптар ---------- */
  let studentsOf = null, studentReset = null;
  V.classes = async () => {
    let st = null;
    if (studentsOf && CL.some(c => c.id === studentsOf)) st = (await api(`/api/classes/${studentsOf}/students`)).students;
    const sc = CL.find(c => c.id === studentsOf);
    return `<div class="stack"><h1>${ME.role === 'admin' ? 'Сыныптар' : 'Сыныптарым'}</h1><p class="lead">Оқушылар тіркелгенде сынып кодын енгізеді. Кодты оқушыларға немесе ата-аналарға беріңіз.</p></div>
    <form class="card" id="newcls"><h3>Жаңа сынып ашу</h3><div class="toolbar">
      <label>Сынып атауы<input id="nc-name" placeholder="Мысалы: 4 «А»" required maxlength="40"></label>
      ${ME.role === 'admin' && TEACHERS ? `<label>Мұғалімі<select id="nc-teacher">${TEACHERS.map(t => `<option value="${t.id}" ${t.id === ME.id ? 'selected' : ''}>${esc(t.name)}</option>`).join('')}</select></label>` : ''}
      <button class="btn" type="submit">Сынып ашу</button></div></form>
    ${CL.length ? `<div class="classcards">${CL.map(c => `<div class="card">
      <div class="row" style="justify-content:space-between"><h2>${esc(c.name)}</h2><span class="chip">${c.studentCount} оқушы</span></div>
      ${ME.role === 'admin' ? `<span class="small muted">Мұғалімі: ${esc(c.teacherName)}</span>` : ''}
      <span class="small muted">Сынып коды</span>
      <div class="row"><span class="code">${esc(c.code)}</span><button class="btn sm alt" data-copy="${esc(c.code)}">Көшіру</button></div>
      <div class="row"><button class="btn sm" data-stu="${c.id}">Оқушылар</button><button class="btn sm alt" data-code="${c.id}">Жаңа код</button>${c.studentCount ? '' : `<button class="btn sm danger" data-delc="${c.id}" data-name="${esc(c.name)}">Өшіру</button>`}</div>
    </div>`).join('')}</div>` : ''}
    ${st ? `<section class="stack"><h2>${esc(sc.name)}: оқушылар</h2>
      ${studentReset ? `<div class="okbox"><b>${esc(studentReset.name)}</b> үшін жаңа құпия сөз: <span class="pw">${esc(studentReset.password)}</span>. Логині: <span class="pw">${esc(studentReset.login)}</span></div>` : ''}
      <div class="tablebox"><table><thead><tr><th>Аты-жөні</th><th>Логин</th><th class="c">Монета</th><th class="c">Орындалған бөлім</th><th class="c">Сурет</th><th>Тіркелген</th><th></th></tr></thead><tbody>
      ${st.length ? st.map(u => `<tr><td><b>${esc(u.name)}</b></td><td>${esc(u.login)}</td><td class="c">${u.coins}</td><td class="c">${u.partsDone}</td><td class="c">${u.drawings}</td><td class="small">${fmtDate(u.createdAt)}</td>
        <td><button class="btn sm alt" data-sreset="${u.id}" data-name="${esc(u.name)}" data-login="${esc(u.login)}">Жаңа құпия сөз</button></td></tr>`).join('') : '<tr><td colspan="7" class="empty">Әлі ешкім тіркелмеген. Оқушыларға сынып кодын беріңіз.</td></tr>'}
      </tbody></table></div></section>` : ''}`;
  };
  A.classes = () => {
    $('#newcls').onsubmit = async e => {
      e.preventDefault();
      try {
        const body = { name: $('#nc-name').value };
        if ($('#nc-teacher')) body.teacherId = $('#nc-teacher').value;
        const r = await api('/api/classes', { method: 'POST', body });
        cls = r.class.id; store.set('cls', cls);
        toast('Сынып ашылды. Коды: ' + r.class.code, 4000);
        await loadBase(); render();
      } catch (er) { toast(er.message, 4000); }
    };
    $$('[data-copy]').forEach(b => (b.onclick = () => {
      navigator.clipboard.writeText(b.dataset.copy).then(() => toast('Код көшірілді'), () => toast('Кодты қолмен көшіріңіз: ' + b.dataset.copy, 4000));
    }));
    $$('[data-stu]').forEach(b => (b.onclick = () => { studentsOf = b.dataset.stu; studentReset = null; render(); }));
    $$('[data-code]').forEach(b => (b.onclick = async () => {
      if (!confirm('Жаңа код жасалады. Ескі код бұдан былай жұмыс істемейді. Жалғастырасыз ба?')) return;
      try { await api('/api/classes/' + b.dataset.code, { method: 'PUT', body: { newCode: true } }); await loadBase(); render(); } catch (e) { toast(e.message); }
    }));
    $$('[data-delc]').forEach(b => (b.onclick = async () => {
      if (!confirm(`«${b.dataset.name}» сыныбын өшіресіз бе?`)) return;
      try { await api('/api/classes/' + b.dataset.delc, { method: 'DELETE' }); await loadBase(); render(); } catch (e) { toast(e.message, 4000); }
    }));
    $$('[data-sreset]').forEach(b => (b.onclick = async () => {
      try {
        const r = await api(`/api/classes/${studentsOf}/students/${b.dataset.sreset}/reset`, { method: 'POST' });
        studentReset = { name: b.dataset.name, login: b.dataset.login, password: r.password };
        render();
      } catch (e) { toast(e.message); }
    }));
  };

  /* ---------- Айдың кітабы ---------- */
  V.month = async () => {
    const c = curClass();
    if (!c) return '<h1>Айдың кітабы</h1>' + noClass();
    return `<div class="stack"><h1>Айдың кітабы</h1><p class="lead">Әр айға бір кітап белгілеңіз. «Ашу» батырмасын басқанда кітап сыныптағы барлық оқушының сөресінде пайда болады. Өткен айлардың кітаптары «Оқыдым» сөресіне түседі.</p></div>
    ${classPicker()}
    <div class="months">${MONTHS.map((m, i) => `<div class="month${i === c.openIdx ? ' open' : ''}">
      <b>${m}</b>
      <select data-plan="${i}" aria-label="${m} кітабы"><option value="">— таңдалмаған —</option>${BOOKS.map(b => `<option value="${b.id}" ${c.plan[i] === b.id ? 'selected' : ''}>${esc(b.title)}${b.author ? ' · ' + esc(b.author) : ''}</option>`).join('')}</select>
      ${i < c.openIdx ? '<span class="chip grey">Аяқталды</span>' : i === c.openIdx ? '<span class="chip gold">Ашық</span>' : `<button class="btn sm alt" data-open="${i}" ${c.plan[i] ? '' : 'disabled'}>Ашу</button>`}
    </div>`).join('')}</div>
    ${c.openIdx >= 0 ? '<button class="btn alt sm" id="closeall" style="align-self:flex-start">Барлық айларды жабу</button>' : ''}`;
  };
  A.month = () => {
    bindClassPicker();
    const c = curClass(); if (!c) return;
    $$('[data-plan]').forEach(s => (s.onchange = async () => {
      const plan = c.plan.slice(); plan[+s.dataset.plan] = s.value;
      try { const r = await api('/api/classes/' + c.id, { method: 'PUT', body: { plan } }); Object.assign(c, r.class); toast('Жоспар сақталды'); render(); } catch (e) { toast(e.message); }
    }));
    $$('[data-open]').forEach(b => (b.onclick = async () => {
      try { const r = await api('/api/classes/' + c.id, { method: 'PUT', body: { openIdx: +b.dataset.open } }); Object.assign(c, r.class); toast(MONTHS[+b.dataset.open] + ' айының кітабы оқушыларға ашылды'); render(); } catch (e) { toast(e.message); }
    }));
    const ca = $('#closeall');
    if (ca) ca.onclick = async () => {
      if (!confirm('Барлық кітап оқушыларға жабылады. Жалғастырасыз ба?')) return;
      try { const r = await api('/api/classes/' + c.id, { method: 'PUT', body: { openIdx: -1 } }); Object.assign(c, r.class); render(); } catch (e) { toast(e.message); }
    };
  };

  /* ---------- Кітаптар ---------- */
  const EB_ACCEPT = '.pdf,.docx,.txt,application/pdf';
  function genBox(b) {
    const k = b.tasks.filter(Boolean).length, has = b.hasText.some(Boolean);
    if (b.gen && b.gen.running) return `<div class="aibox"><span class="small" aria-live="polite">AI: ${esc(b.gen.msg)}…</span><button class="btn alt sm" data-stop="${b.id}">Тоқтату</button></div>`;
    return `<div class="aibox"><span class="chip ${k ? '' : 'grey'}" style="align-self:flex-start">Тапсырмалар: ${k} / ${b.parts.length} бөлім</span>
      ${b.gen && b.gen.msg && !b.gen.running ? `<span class="small muted">${esc(b.gen.msg)}</span>` : ''}
      ${STATUS.ai ? `<button class="btn sm ${k ? 'alt' : ''}" data-gen="${b.id}" ${has ? '' : 'disabled'}>${k ? 'AI-мен қайта дайындау' : 'AI-мен тапсырма дайындау'}</button>` : '<span class="small muted">AI өшірулі (әкімші API кілтін орнатуы керек)</span>'}
      ${has ? '' : '<span class="small muted">Мәтіні бар электронды нұсқа жүктеңіз</span>'}
      ${k ? `<details><summary class="small" style="cursor:pointer;color:var(--teal)">Дайын тапсырмаларды қарау</summary><div class="stack" style="gap:10px;margin-top:8px">${b.parts.map((p, i) => {
        const g = b.tasks[i];
        if (!g) return `<p class="small muted">${i + 1}. ${esc(p)}: дайын емес</p>`;
        return `<div class="small"><b>${i + 1}. ${esc(p)}</b><ol style="margin:4px 0;padding-left:18px">${g.quiz.map(q => `<li>${esc(q.q)} <span class="muted">(${esc(q.o[q.a])})</span></li>`).join('')}</ol>${g.seq ? `<span class="muted">Пазл: ${g.seq.map(esc).join(' → ')}</span>` : ''}${g.comic ? `<br><span class="muted">Комикс: ${g.comic.panels.map(x => esc(x.scene)).join(' · ')}</span>` : ''}</div>`;
      }).join('')}</div></details>` : ''}
    </div>`;
  }
  V.books = async () => {
    BOOKS = (await api('/api/books')).books;
    return `<div class="stack"><h1>Кітаптар</h1><p class="lead">Кітап қоры бүкіл мектепке ортақ. Мұқабаны сурет ретінде, мәтінді электронды нұсқа (PDF, Word, TXT) ретінде жүктеңіз. Электронды нұсқа жүктелгенде AI әр бөлімге куиз, пазл, комикс және сурет тапсырмасын өзі дайындайды.</p></div>
    <form class="card" id="nb"><h2>Жаңа кітап қосу</h2>
      <div class="toolbar"><label>Атауы<input id="nb-t" required maxlength="120" placeholder="Мысалы: Қаңбақ шал"></label><label>Авторы<input id="nb-a" maxlength="120" placeholder="Қазақ халық ертегісі"></label></div>
      <label>Бөлімдер (әр жолға бір бөлім)<textarea id="nb-p" placeholder="1-тарау&#10;2-тарау&#10;3-тарау"></textarea></label>
      <div class="toolbar"><label>Мұқаба (сурет)<input id="nb-c" type="file" accept="image/*"></label><label>Электронды нұсқа (PDF, Word, TXT)<input id="nb-f" type="file" accept="${EB_ACCEPT}"></label></div>
      <p class="err" id="nb-err"></p>
      <button class="btn" type="submit" style="align-self:flex-start">Кітапты қосу</button>
    </form>
    <section class="stack"><h2>Кітап қоры</h2><div class="assets">${BOOKS.map(b => { const e = b.ebook, edit = canEditBook(b); return `<div class="card">${coverHtml(b)}
      <b class="small">${esc(b.title)}</b><span class="small muted">${esc(b.author || '')}</span>
      <span class="chip ${e ? '' : 'grey'}" style="align-self:flex-start">${e ? (e.kind === 'pdf' ? `PDF${e.pages ? ' · ' + e.pages + ' бет' : ''}` : 'Мәтін жүктелді') : b.hasText.some(Boolean) ? 'Мәтін бар' : 'Электронды нұсқа жоқ'}</span>
      ${edit ? `<label class="btn alt sm fl" for="cf-${b.id}">${b.cover ? 'Мұқабаны ауыстыру' : 'Мұқаба жүктеу'}</label><input id="cf-${b.id}" data-cf="${b.id}" type="file" accept="image/*" hidden>
      <label class="btn alt sm fl" for="ef-${b.id}">${e ? 'Нұсқаны ауыстыру' : 'Электронды нұсқа'}</label><input id="ef-${b.id}" data-ef="${b.id}" type="file" accept="${EB_ACCEPT}" hidden>` : '<span class="small muted">Басқа мұғалім қосқан</span>'}
      ${edit && e && e.kind === 'pdf' && e.pages ? `<details><summary class="small" style="cursor:pointer;color:var(--teal)">Бөлімдердің беттері</summary><div class="stack" style="gap:6px;margin-top:8px">${b.parts.map((p, i) => { const r = (b.ranges || evenRanges(e.pages, b.parts.length))[i] || [1, 1]; return `<div class="rg"><span class="small">${i + 1}. ${esc(p)}</span><input type="number" min="1" max="${e.pages}" value="${r[0]}" data-rf="${b.id}|${i}|0" aria-label="${i + 1}-бөлімнің бірінші беті"><span>–</span><input type="number" min="1" max="${e.pages}" value="${r[1]}" data-rf="${b.id}|${i}|1" aria-label="${i + 1}-бөлімнің соңғы беті"></div>`; }).join('')}<button class="btn sm" data-rs="${b.id}" style="align-self:flex-start">Беттерді сақтау</button></div></details>` : ''}
      ${genBox(b)}
      ${edit && b.createdBy !== 'system' || ME.role === 'admin' ? `<button class="btn sm danger" data-delb="${b.id}" data-name="${esc(b.title)}" style="align-self:flex-start">Өшіру</button>` : ''}
    </div>`; }).join('')}</div></section>`;
  };
  A.books = () => {
    $('#nb').onsubmit = async e => {
      e.preventDefault();
      const btn = e.submitter || $('#nb button[type=submit]'), errEl = $('#nb-err');
      errEl.textContent = '';
      const parts = $('#nb-p').value.split('\n').map(x => x.trim()).filter(Boolean);
      const meta = { title: $('#nb-t').value.trim(), author: $('#nb-a').value.trim(), parts: parts.length ? parts : ['1-бөлім', '2-бөлім', '3-бөлім'] };
      const fd = new FormData();
      btn.disabled = true; btn.textContent = 'Файлдар өңделіп жатыр…';
      try {
        const cf = $('#nb-c').files[0], ef = $('#nb-f').files[0];
        if (cf) fd.append('cover', await resizeImage(cf, 480, 640), 'cover.jpg');
        if (ef) { Object.assign(meta, await prepareEbook(ef, meta.parts.length)); fd.append('ebook', ef, ef.name); }
        fd.append('meta', JSON.stringify(meta));
        btn.textContent = 'Жүктеліп жатыр…';
        await api('/api/books', { method: 'POST', body: fd });
        toast('Кітап қосылды. Енді оны «Айдың кітабы» бөлімінде айға белгілеңіз', 4000);
        render();
      } catch (er) { errEl.textContent = er.message; btn.disabled = false; btn.textContent = 'Кітапты қосу'; }
    };
    $$('[data-cf]').forEach(i => (i.onchange = async e => {
      const f = e.target.files[0]; e.target.value = ''; if (!f) return;
      try { const fd = new FormData(); fd.append('cover', await resizeImage(f, 480, 640), 'cover.jpg'); await api(`/api/books/${i.dataset.cf}/cover`, { method: 'POST', body: fd }); toast('Мұқаба сақталды'); render(); }
      catch (er) { toast(er.message, 4000); }
    }));
    $$('[data-ef]').forEach(i => (i.onchange = async e => {
      const f = e.target.files[0]; e.target.value = ''; if (!f) return;
      const b = bookById(i.dataset.ef);
      toast('Файл өңделіп жатыр…');
      try {
        const meta = await prepareEbook(f, b.parts.length);
        const fd = new FormData(); fd.append('ebook', f, f.name); fd.append('meta', JSON.stringify(meta));
        await api(`/api/books/${b.id}/ebook`, { method: 'POST', body: fd });
        toast(STATUS.ai ? 'Электронды нұсқа жүктелді. AI тапсырмаларды дайындап жатыр' : 'Электронды нұсқа жүктелді', 4000);
        render();
      } catch (er) { toast(er.message, 4000); }
    }));
    $$('[data-rs]').forEach(btn => (btn.onclick = async () => {
      const b = bookById(btn.dataset.rs), pages = b.ebook.pages;
      const cur = (b.ranges || evenRanges(pages, b.parts.length)).map(x => x.slice());
      $$('[data-rf]').filter(inp => inp.dataset.rf.startsWith(b.id + '|')).forEach(inp => { const [, i, k] = inp.dataset.rf.split('|'); cur[i][k] = Math.min(pages, Math.max(1, +inp.value || 1)); });
      if (cur.some(x => x[1] < x[0])) { toast('Бөлімнің соңғы беті бірінші бетінен кіші болмауы керек'); return; }
      btn.disabled = true; btn.textContent = 'Мәтін қайта алынып жатыр…';
      try {
        const doc = await openPdfUrl(fileUrl(b.ebook.file));
        const texts = await pdfRangeTexts(doc, cur);
        await api('/api/books/' + b.id, { method: 'PUT', body: { ranges: cur, texts } });
        toast('Беттер сақталды. Тапсырмаларды жаңарту үшін AI-мен қайта дайындаңыз', 4000);
        render();
      } catch (er) { toast(er.message, 4000); btn.disabled = false; btn.textContent = 'Беттерді сақтау'; }
    }));
    $$('[data-gen]').forEach(b => (b.onclick = async () => {
      try { await api(`/api/books/${b.dataset.gen}/generate`, { method: 'POST' }); render(); } catch (e) { toast(e.message, 4000); }
    }));
    $$('[data-stop]').forEach(b => (b.onclick = async () => { try { await api(`/api/books/${b.dataset.stop}/generate/stop`, { method: 'POST' }); toast('Тоқтатылады'); } catch (e) { toast(e.message); } }));
    $$('[data-delb]').forEach(b => (b.onclick = async () => {
      if (!confirm(`«${b.dataset.name}» кітабын өшіресіз бе?`)) return;
      try { await api('/api/books/' + b.dataset.delb, { method: 'DELETE' }); toast('Кітап өшірілді'); render(); } catch (e) { toast(e.message, 4000); }
    }));
    // AI жұмыс істеп жатса, күйін жаңартып тұру
    if (BOOKS.some(b => b.gen && b.gen.running)) pollT = setTimeout(async () => {
      if (tab !== 'books' || document.activeElement && /INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)) { if (tab === 'books') A.books.repoll(); return; }
      render();
    }, 3000);
  };
  A.books.repoll = () => { pollT = setTimeout(() => { if (tab === 'books') render(); }, 4000); };

  /* ---------- Бағалау ---------- */
  let gbook = null;
  function classBooks(c) { return c.plan.map((id, i) => ({ id, i })).filter(x => x.id && x.i <= c.openIdx).map(x => bookById(x.id)).filter(Boolean); }
  async function gradesData() {
    const c = curClass();
    if (!c) return { c: null };
    const avail = classBooks(c);
    if (!gbook || !avail.some(b => b.id === gbook)) gbook = c.openIdx >= 0 && c.plan[c.openIdx] ? c.plan[c.openIdx] : avail[0] && avail[0].id;
    if (!gbook) return { c, avail };
    const G = await api(`/api/classes/${c.id}/grades?bookId=${encodeURIComponent(gbook)}`);
    return { c, avail, G };
  }
  const bookPicker = avail => `<label style="max-width:320px">Кітап<select id="gbook">${avail.map(b => `<option value="${b.id}" ${b.id === gbook ? 'selected' : ''}>${esc(b.title)}</option>`).join('')}</select></label>`;
  const legend = () => `<div class="legend"><span>${dot('r')} Оқымады немесе түсінбеді</span><span>${dot('y')} Жартылай түсінді</span><span>${dot('g')} Толық меңгерді</span><span>${dot(null)} Әлі орындамады</span></div>`;
  V.grades = async () => {
    const { c, avail, G } = await gradesData();
    if (!c) return '<h1>Бағалау</h1>' + noClass();
    if (!G) return `<h1>Бағалау</h1>${classPicker()}<p class="muted">Бұл сыныпта әлі ашылған кітап жоқ. «Айдың кітабы» бөлімінде кітапты ашыңыз.</p>`;
    const red = G.students.filter(s => s.cells.some(x => x.color === 'r')).map(s => s.name);
    const pending = G.students.filter(s => s.cells.some(x => !x.color)).map(s => s.name);
    return `<div class="stack"><h1>Бағалау</h1><p class="lead">Түс оқушының куиз бен пазл нәтижесінен өзі қойылады. Өзгерту үшін шеңберді басыңыз: қызыл → сары → жасыл → автоматты.</p></div>
    <div class="toolbar">${classPicker()}${bookPicker(avail)}<a class="btn alt sm" href="/api/classes/${c.id}/export.csv" style="text-decoration:none;align-self:flex-end">Excel-ге жүктеу (CSV)</a></div>
    ${legend()}
    <div class="sum">${G.book.parts.map((p, i) => { const cnt = { g: 0, y: 0, r: 0 }; G.students.forEach(s => { const x = s.cells[i].color; if (x) cnt[x]++; }); const n = G.students.length || 1; return `<div class="card"><span class="small muted">${i + 1}-бөлім</span><b>${esc(p)}</b>
      <div class="bar3">${['g', 'y', 'r'].map(k => `<div style="width:${cnt[k] / n * 100}%;background:var(--${k})"></div>`).join('')}</div>
      <span class="small muted">${cnt.g} жасыл · ${cnt.y} сары · ${cnt.r} қызыл</span></div>`; }).join('')}</div>
    <div class="tablebox"><table><thead><tr><th>Оқушы</th>${G.book.parts.map((p, i) => `<th class="c">${i + 1}-бөлім</th>`).join('')}</tr></thead>
    <tbody>${G.students.length ? G.students.map(s => `<tr><td><b>${esc(s.name)}</b></td>${s.cells.map((x, i) => `<td class="c"><button class="cbtn" data-g="${s.id}|${i}" data-cur="${x.override ? x.color : 'auto'}" title="${x.color ? COLOR_TXT[x.color] : 'Әлі орындамады'}${x.score !== null ? ' · ' + x.score + '%' : ''}${x.override ? ' · мұғалім қойды' : ''}" aria-label="${esc(s.name)}, ${i + 1}-бөлім: ${x.color ? COLOR_TXT[x.color] : 'әлі орындамады'}">${dot(x.color)}${x.override ? '<sup class="small muted">✎</sup>' : ''}</button></td>`).join('')}</tr>`).join('') : `<tr><td colspan="${G.book.parts.length + 1}" class="empty">Сыныпта әлі оқушы жоқ</td></tr>`}</tbody></table></div>
    <div class="card"><h3>Қолдау қажет</h3>
      <p class="small">${red.length ? `<b>${red.map(esc).join(', ')}</b>: кем дегенде бір бөлім қызыл. Бөлімді қайта оқып, жұпта талқылауды ұсыныңыз.` : 'Қызыл белгі жоқ.'}</p>
      ${pending.length ? `<p class="small muted">Әлі орындамағандар: ${pending.map(esc).join(', ')}.</p>` : ''}
      <p class="small muted">Бұл тізім тек бағыт береді. Түпкі бағаны мұғалім қояды.</p></div>`;
  };
  A.grades = () => {
    bindClassPicker();
    const gb = $('#gbook'); if (gb) gb.onchange = () => { gbook = gb.value; render(); };
    const NEXT = { auto: 'r', r: 'y', y: 'g', g: 'auto', null: 'r' };
    $$('[data-g]').forEach(b => (b.onclick = async () => {
      const [sid, i] = b.dataset.g.split('|');
      try { await api(`/api/classes/${curClass().id}/grades`, { method: 'PUT', body: { studentId: sid, bookId: gbook, part: +i, color: NEXT[b.dataset.cur] } }); render(); }
      catch (e) { toast(e.message); }
    }));
  };

  /* ---------- Ай есебі ---------- */
  let reportText = '';
  V.report = async () => {
    const { c, avail, G } = await gradesData();
    if (!c) return '<h1>Ай есебі</h1>' + noClass();
    if (!G) return `<h1>Ай есебі</h1>${classPicker()}<p class="muted">Бұл сыныпта әлі ашылған кітап жоқ.</p>`;
    const n = G.book.parts.length, S = G.students;
    const cnt = { g: 0, y: 0, r: 0, none: 0 };
    S.forEach(s => s.cells.forEach(x => cnt[x.color || 'none']++));
    const tot = S.length * n, doneN = tot - cnt.none, pct = x => (tot ? Math.round(x / tot * 100) : 0);
    const val = { g: 3, y: 2, r: 1 }, avg = v => (v.length ? v.reduce((a, x) => a + x, 0) / v.length : 0);
    const per = S.map(s => { const v = s.cells.filter(x => x.color).map(x => val[x.color]); const a = avg(v); return { nm: s.name, cells: s.cells, done: v.length, col: !v.length ? null : a >= 2.5 ? 'g' : a >= 1.75 ? 'y' : 'r' }; });
    const ps = G.book.parts.map((p, i) => { const v = S.map(s => s.cells[i].color).filter(Boolean).map(x => val[x]); return { p, avg: avg(v), n: v.length }; }).filter(x => x.n);
    const best = ps.slice().sort((a, b) => b.avg - a.avg)[0], worst = ps.slice().sort((a, b) => a.avg - b.avg)[0];
    const grp = k => per.filter(x => x.col === k).map(x => x.nm), g = grp('g'), y = grp('y'), r = grp('r'), inc = per.filter(x => x.done < n).map(x => x.nm);
    const monthIdx = c.plan.indexOf(G.book.id);
    const recs = [];
    if (r.length) recs.push(`${r.join(', ')}: бөлімдерді қайта оқып, жұпта немесе шағын топта талқылау.`);
    if (worst && best && worst !== best && worst.avg < 2.5) recs.push(`«${worst.p}» бөлімі бойынша қайталау сабағын өткізу: оқиғаның реті мен негізгі ойын бірге талдау.`);
    if (y.length) recs.push(`${y.join(', ')}: мәтіннен дәлел табуға арналған қосымша сұрақтар беру.`);
    if (inc.length) recs.push(`${inc.join(', ')}: тапсырмаларды толық орындамады, ата-анасымен бірге оқу кестесін құру.`);
    if (g.length) recs.push(`${g.join(', ')}: «Үздік оқырман» ретінде мадақтап, келесі айда сыныптастарына кітап таныстыруды ұсыну.`);
    reportText = [`«${G.book.title}» кітабы бойынша ${monthIdx >= 0 ? MONTHS[monthIdx].toLowerCase() + ' айының' : ''} есебі`, '',
      `Сынып: ${c.name}. Оқушы саны: ${S.length}. Кітап бөлімдері: ${n}.`,
      `Тапсырмалардың орындалуы: ${doneN} / ${tot} (${pct(doneN)}%).`,
      `Бағалау: толық меңгерді — ${cnt.g} (${pct(cnt.g)}%), жартылай түсінді — ${cnt.y} (${pct(cnt.y)}%), оқымады немесе түсінбеді — ${cnt.r} (${pct(cnt.r)}%).`,
      best ? `Ең жақсы меңгерілген бөлім: «${best.p}». Ең қиын болған бөлім: «${worst.p}».` : '',
      '', `Толық меңгергендер: ${g.join(', ') || 'жоқ'}.`, `Жартылай меңгергендер: ${y.join(', ') || 'жоқ'}.`, `Қолдау қажет: ${r.join(', ') || 'жоқ'}.`,
      `Шығармашылық жұмыстар: ${G.drawings} сурет.`, '', 'Ұсыныстар:', ...recs.map((x, i) => `${i + 1}. ${x}`)].join('\n').replace(/\n{3,}/g, '\n\n');
    return `<div class="stack"><h1>Ай есебі</h1><p class="lead">Ай соңында оқушылардың жетістігі мен қолдау қажет тұстары өзі жинақталады.</p></div>
    <div class="toolbar">${classPicker()}${bookPicker(avail)}</div>
    <div class="kpis">
      <div class="card kpi"><span class="small muted">Орындалуы</span><b>${pct(doneN)}%</b><span class="small muted">${doneN} / ${tot} бөлім</span></div>
      <div class="card kpi"><span class="small muted row" style="gap:6px">${dot('g')} Толық меңгерді</span><b>${pct(cnt.g)}%</b></div>
      <div class="card kpi"><span class="small muted row" style="gap:6px">${dot('y')} Жартылай түсінді</span><b>${pct(cnt.y)}%</b></div>
      <div class="card kpi"><span class="small muted row" style="gap:6px">${dot('r')} Түсінбеді</span><b>${pct(cnt.r)}%</b></div>
    </div>
    <div class="tablebox"><table><thead><tr><th>Оқушы</th>${G.book.parts.map((_, i) => `<th class="c">${i + 1}-бөлім</th>`).join('')}<th class="c">Жалпы</th></tr></thead>
    <tbody>${per.map(x => `<tr><td><b>${esc(x.nm)}</b></td>${x.cells.map(cl => `<td class="c">${dot(cl.color)}</td>`).join('')}<td class="c">${dot(x.col)}</td></tr>`).join('')}</tbody></table></div>
    <div class="sum">
      <div class="card"><h3>Жетістіктер</h3><p class="small">${g.length ? `<b>${g.map(esc).join(', ')}</b> кітапты толық меңгерді.` : 'Кітапты толық меңгерген оқушы әлі жоқ.'}</p>${best ? `<p class="small">Ең жақсы меңгерілген бөлім: «${esc(best.p)}».</p>` : ''}<p class="small muted">${G.drawings} шығармашылық жұмыс жүктелді.</p></div>
      <div class="card"><h3>Қолдау қажет</h3><p class="small">${r.length ? `<b>${r.map(esc).join(', ')}</b>` : 'Қызыл белгісі бар оқушы жоқ.'}</p>${worst && worst !== best ? `<p class="small">Қиын болған бөлім: «${esc(worst.p)}».</p>` : ''}${inc.length ? `<p class="small muted">Толық орындамағандар: ${inc.map(esc).join(', ')}.</p>` : ''}</div>
    </div>
    <section class="card"><div class="row" style="justify-content:space-between"><h3>Есеп мәтіні</h3><button class="btn" id="copyr">Есепті көшіру</button></div>
      <textarea id="rtext" class="rtext" readonly aria-label="Есеп мәтіні">${esc(reportText)}</textarea>
      <p class="small muted">Мәтінді Word құжатына немесе ата-аналар чатына қоюға болады. Толық кесте керек болса, «Бағалау» бөлімінен Excel файлын жүктеңіз.</p></section>`;
  };
  A.report = () => {
    bindClassPicker();
    const gb = $('#gbook'); if (gb) gb.onchange = () => { gbook = gb.value; render(); };
    const c = $('#copyr');
    if (c) c.onclick = () => {
      const t = $('#rtext');
      const fb = () => { t.focus(); t.select(); toast('Мәтін белгіленді. Көшіру үшін Ctrl+C басыңыз'); };
      try { navigator.clipboard.writeText(t.value).then(() => toast('Есеп көшірілді'), fb); } catch (e) { fb(); }
    };
  };

  /* ---------- Шығармашылық жұмыстар ---------- */
  let galAll = false;
  V.gallery = async () => {
    const c = curClass();
    if (!c) return '<h1>Шығармашылық жұмыстар</h1>' + noClass();
    const q = galAll ? '' : '?classId=' + encodeURIComponent(c.id);
    const { drawings } = await api('/api/drawings' + q);
    return `<div class="stack"><h1>Шығармашылық жұмыстар</h1><p class="lead">Оқушылар әр бөлімнен кейін салған немесе жүктеген суреттер.</p></div>
    <div class="toolbar"><label style="max-width:320px">Сынып<select id="gcls"><option value="">Барлық сыныптар</option>${CL.map(k => `<option value="${k.id}" ${!galAll && k.id === c.id ? 'selected' : ''}>${esc(k.name)}</option>`).join('')}</select></label></div>
    ${drawings.length ? `<div class="gallery">${drawings.map(w => `<figure class="card" style="margin:0"><img src="${fileUrl(w.file)}" alt="${esc(w.studentName)} салған сурет" loading="lazy">
      <figcaption class="stack" style="gap:4px"><b>${esc(w.studentName)} · ${esc(w.className)}</b><span class="small">${esc(w.bookTitle)}, ${w.part + 1}-бөлім · ${fmtDate(w.at)}</span><span class="small muted">${esc(w.prompt)}</span>${w.cap ? `<span class="small">«${esc(w.cap)}»</span>` : ''}</figcaption></figure>`).join('')}</div>`
      : '<div class="card empty">Әзірге сурет жоқ. Оқушы әр бөлімнің соңында сурет салғанда, ол осында шығады.</div>'}`;
  };
  A.gallery = () => { $('#gcls').onchange = e => { if (e.target.value) { cls = e.target.value; store.set('cls', cls); galAll = false; } else galAll = true; render(); }; };

  /* ---------- Аккаунтым ---------- */
  V.account = async () => `<div class="stack"><h1>Аккаунтым</h1><p class="lead">${esc(ME.name)} · логин: <b>${esc(ME.login)}</b> · ${ROLE_NAME[ME.role]}</p></div>
    <form class="card" id="pwf" style="max-width:460px"><h3>Құпия сөзді өзгерту</h3>
      <label>Қазіргі құпия сөз<input id="pw-old" type="password" autocomplete="current-password" required></label>
      <label>Жаңа құпия сөз (кемінде 6 таңба)<input id="pw-new" type="password" autocomplete="new-password" required></label>
      <p class="err" id="pw-err"></p>
      <button class="btn" type="submit" style="align-self:flex-start">Сақтау</button></form>`;
  A.account = () => {
    $('#pwf').onsubmit = async e => {
      e.preventDefault();
      try { await api('/api/me/password', { method: 'POST', body: { old: $('#pw-old').value, password: $('#pw-new').value } }); toast('Құпия сөз өзгертілді'); render(); }
      catch (er) { $('#pw-err').textContent = er.message; }
    };
  };

  return { start };
})();
