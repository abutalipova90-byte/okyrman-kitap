/* «Оқырман мектеп»: оқушы беті */
const Student = (() => {
  let H = null;              // сервердегі деректер: plan, books, progress, coins
  let sv = { screen: 'shelf' };
  let lastCoins = null;

  const starsOf = p => (!p || !p.done ? 0 : p.score >= 0.85 ? 3 : p.score >= 0.5 ? 2 : 1);
  const progressOf = id => (H.progress[id] || []);
  const bookFinished = id => { const b = H.books[id]; return !!b && b.parts.every((_, i) => progressOf(id)[i] && progressOf(id)[i].done); };
  const LEVELS = [[0, 'Бастаушы оқырман'], [100, 'Білгір оқырман'], [250, 'Алтын оқырман'], [500, 'Кітап шебері']];
  function level(c) { let k = 0; LEVELS.forEach((l, i) => { if (c >= l[0]) k = i; }); return { k, name: LEVELS[k][1], next: LEVELS[k + 1] }; }
  const content = (id, i) => { const b = H.books[id]; return (b && b.tasks && b.tasks[i]) || null; };

  async function start(home) {
    if (home || !H) sv = { screen: 'shelf' };
    $('#main').innerHTML = '<p class="loading">Кітап сөрең ашылып жатыр…</p>';
    try { H = await api('/api/student/home'); }
    catch (e) { $('#main').innerHTML = `<p class="empty">${esc(e.message)}</p>`; return; }
    render();
  }
  function header() {
    const st = $('#stars');
    st.hidden = false;
    st.innerHTML = coin(17) + ' ' + H.coins;
    st.title = 'Монеталарым';
    if (lastCoins !== null && H.coins > lastCoins) { st.classList.remove('bump'); void st.offsetWidth; st.classList.add('bump'); }
    lastCoins = H.coins;
  }
  function render() {
    header();
    $('#main').innerHTML = `<div class="view">${V[sv.screen]()}</div>`;
    (VA[sv.screen] || (() => {}))();
  }
  function go(s) { sv = Object.assign({}, sv, s); render(); window.scrollTo(0, 0); }

  /* ---------- Қазына ---------- */
  function treasure() {
    const c = H.coins, lv = level(c);
    const fin = Object.keys(H.books).filter(bookFinished);
    const pct = lv.next ? Math.round((c - LEVELS[lv.k][0]) / (lv.next[0] - LEVELS[lv.k][0]) * 100) : 100;
    return `<section class="treasure">
      <div class="t-coins">${coin(46)}<div><b class="num">${c}</b><span>монета</span></div></div>
      <div class="t-level"><span class="small">Деңгейің</span><b>${lv.name}</b><div class="meter gold"><div style="width:${pct}%"></div></div>
        <span class="small">${lv.next ? `«${lv.next[1]}» деңгейіне ${lv.next[0] - c} монета қалды` : 'Ең жоғарғы деңгейге жеттің!'}</span></div>
      <div class="t-medals"><span class="small">Медальдарым</span><div class="row" style="gap:8px">${fin.length ? fin.map(id => `<span class="m" style="--mc:${esc(H.books[id].color)}" title="${esc(H.books[id].title)}">${star(18, true)}</span>`).join('') : '<span class="small">Кітапты аяқтасаң, медаль аласың</span>'}</div></div>
    </section>`;
  }

  const V = {}, VA = {};
  const partsDone = id => progressOf(id).filter(p => p && p.done).length;

  /* ---------- Кітап сөресі ---------- */
  V.shelf = () => {
    const first = (ME.name || '').split(' ')[0];
    const cur = H.plan.find(p => p.state === 'open');
    const read = H.plan.filter(p => p.state === 'done');
    const next = H.plan.filter(p => p.state === 'locked');
    const cb = cur && H.books[cur.bookId];
    const n = cb ? cb.parts.length : 0, d = cb ? partsDone(cb.id) : 0;
    return `
    <div class="stack"><div class="hello"><span class="wave" aria-hidden="true">👋</span><h1>Сәлем, ${esc(first)}!</h1></div>
      <p class="lead">${!ME.classId ? 'Сен әлі сыныпқа қосылмағансың. Мұғаліміңе айт.' : cb ? `Мұғалімің ${MONTHS[cur.month].toLowerCase()} айына «${esc(cb.title)}» кітабын ашты.` : 'Мұғалімің бұл айдың кітабын әлі ашқан жоқ.'}</p></div>
    ${treasure()}
    ${cb ? `<section class="shelf"><div class="shelf-head"><h2>Оқып жатырмын</h2></div>
      <div class="card current">
        <button class="book" data-book="${cb.id}" aria-label="${esc(cb.title)} кітабын ашу">${coverHtml(cb)}</button>
        <div class="stack">
          <span class="chip gold" style="align-self:flex-start">${MONTHS[cur.month]} айының кітабы</span>
          <h2>${esc(cb.title)}</h2><span class="muted">${esc(cb.author || '')}</span>
          <div class="meter"><div style="width:${n ? d / n * 100 : 0}%"></div></div>
          <span class="small muted">${d} / ${n} бөлім оқылды</span>
          <button class="btn gold" data-book="${cb.id}" style="align-self:flex-start">${d === 0 ? 'Оқуды бастау' : d < n ? 'Оқуды жалғастыру' : 'Кітапты қайта ашу'}</button>
        </div>
      </div></section>` : ''}
    <section class="shelf"><div class="shelf-head"><h2>Оқыдым</h2><span class="muted small">${read.length} кітап</span></div>
      ${read.length ? `<div class="books">${read.map(p => { const b = H.books[p.bookId]; const s = progressOf(b.id).reduce((a, x) => a + starsOf(x), 0); return `<button class="book" data-book="${b.id}">${coverHtml(b)}<span class="t">${esc(b.title)}</span><span class="small muted row" style="gap:4px">${star(14, true)} ${s} / ${b.parts.length * 3}</span></button>`; }).join('')}</div>` : '<p class="muted small">Әзірге оқылған кітап жоқ.</p>'}
    </section>
    <section class="shelf"><div class="shelf-head"><h2>Оқимын</h2><span class="muted small">мұғалім ашқанда қолжетімді болады</span></div>
      ${next.length ? `<div class="books">${next.map(p => { const b = H.books[p.bookId]; return `<button class="book" disabled>${coverHtml(b, true)}<span class="t">${esc(b.title)}</span><span class="small muted">${NEXT_IN[p.month]} ашылады</span></button>`; }).join('')}</div>` : '<p class="muted small">Келесі кітаптар әлі белгіленбеген.</p>'}
    </section>`;
  };
  VA.shelf = () => $$('[data-book]').forEach(b => (b.onclick = () => go({ screen: 'book', book: b.dataset.book })));

  /* ---------- Кітап беті ---------- */
  V.book = () => {
    const b = H.books[sv.book], pr = progressOf(b.id);
    return `
    <div class="row"><button class="btn alt" id="back">← Сөреге</button></div>
    <div class="current" style="grid-template-columns:140px 1fr">${coverHtml(b)}<div class="stack"><h1>${esc(b.title)}</h1><span class="muted">${esc(b.author || '')}</span><p class="small muted">Әр бөлімді оқып болған соң: куиз, пазл, комикс және сурет.</p></div></div>
    <div class="parts">${b.parts.map((p, i) => {
      const done = pr[i] && pr[i].done, open = i === 0 || (pr[i - 1] && pr[i - 1].done);
      return `<button class="part${done ? ' done' : ''}" data-part="${i}" ${open ? '' : 'disabled'}><span class="n">${i + 1}</span><span class="body"><b>${esc(p)}</b><span class="small muted">${done ? 'Аяқталды' : open ? 'Оқуға дайын' : 'Алдыңғы бөлімді аяқта'}</span></span>${done ? `<span class="row" style="gap:2px">${[1, 2, 3].map(k => star(18, k <= starsOf(pr[i]))).join('')}</span>` : open ? '<span class="chip">Бастау</span>' : ''}</button>`;
    }).join('')}</div>`;
  };
  VA.book = () => {
    $('#back').onclick = () => go({ screen: 'shelf' });
    $$('[data-part]').forEach(b => (b.onclick = () => go({ screen: 'part', part: +b.dataset.part, step: 'read', res: {} })));
  };

  /* ---------- Бөлім қадамдары ---------- */
  function stepsFor() {
    const c = content(sv.book, sv.part);
    return c ? [['read', 'Оқу'], ['quiz', 'Куиз'], ['puzzle', 'Пазл'], ['comic', 'Комикс'], ['draw', 'Сурет']].filter(x => (x[0] !== 'comic' || c.comic) && (x[0] !== 'puzzle' || c.seq))
      : [['read', 'Оқу'], ['think', 'Ойлан'], ['draw', 'Сурет']];
  }
  function stepBar() {
    const st = stepsFor(), k = st.findIndex(x => x[0] === sv.step);
    return `<div class="steps">${st.map((x, i) => `<span class="${i === k ? 'on' : i < k || sv.step === 'done' ? 'ok' : ''}">${x[1]}</span>`).join('')}</div>`;
  }
  function nextStep() { const st = stepsFor().map(x => x[0]), k = st.indexOf(sv.step); go({ step: k < st.length - 1 ? st[k + 1] : 'done' }); }
  function partHead() {
    const b = H.books[sv.book];
    return `<div class="row" style="justify-content:space-between"><button class="btn alt" id="back">← ${esc(b.title)}</button>${stepBar()}</div><div class="stack" style="gap:4px"><span class="small muted">${sv.part + 1}-бөлім</span><h1>${esc(b.parts[sv.part])}</h1></div>`;
  }
  V.part = () => partHead() + P[sv.step]();
  VA.part = () => { $('#back').onclick = () => go({ screen: 'book' }); (PA[sv.step] || (() => {}))(); };
  const P = {}, PA = {};
  let qs = { i: 0, ok: 0, picked: null }, pz = null;

  /* Оқу */
  function partRange(b, i) {
    if (b.ranges && b.ranges[i]) return b.ranges[i];
    return b.ebook && b.ebook.pages ? evenRanges(b.ebook.pages, b.parts.length)[i] : null;
  }
  P.read = () => {
    const b = H.books[sv.book], txt = b.texts && b.texts[sv.part];
    let body;
    const rg = b.ebook && b.ebook.kind === 'pdf' ? partRange(b, sv.part) : null;
    if (rg) body = `<p class="small muted">Электронды кітап · ${rg[0]}–${rg[1]}-беттер</p><div class="pdfpages" id="pdfpages" data-from="${rg[0]}" data-to="${rg[1]}"><p class="muted">Кітап ашылып жатыр…</p></div>`;
    else if (txt) body = `<div class="txt">${txt.split(/\n+/).map(p => `<p>${esc(p)}</p>`).join('')}</div>`;
    else body = '<p class="txt">Бұл бөлімді кітабыңнан оқы. Оқып болған соң төмендегі батырманы бас.</p>';
    return `<article class="reader">${body}<button class="btn gold" id="next" style="align-self:flex-start">Оқып болдым</button></article>`;
  };
  PA.read = () => {
    qs = { i: 0, ok: 0, picked: null }; pz = null;
    $('#next').onclick = nextStep;
    const box = $('#pdfpages');
    if (box) renderPdf(fileUrl(H.books[sv.book].ebook.file), +box.dataset.from, +box.dataset.to, box);
  };
  async function renderPdf(url, from, to, box) {
    try {
      const doc = await openPdfUrl(url);
      box.innerHTML = '';
      const W = box.clientWidth || 700, dpr = Math.min(2, window.devicePixelRatio || 1);
      for (let p = from; p <= Math.min(to, doc.numPages); p++) {
        if (!box.isConnected) return;
        const pg = await doc.getPage(p), v0 = pg.getViewport({ scale: 1 }), vp = pg.getViewport({ scale: W / v0.width * dpr });
        const cv = document.createElement('canvas');
        cv.width = vp.width; cv.height = vp.height; cv.className = 'pdfpage'; cv.setAttribute('aria-label', p + '-бет');
        box.appendChild(cv);
        await pg.render({ canvasContext: cv.getContext('2d'), viewport: vp }).promise;
      }
    } catch (e) { box.innerHTML = '<p class="muted">Электронды кітапты ашу мүмкін болмады. Бұл бөлімді қағаз кітаптан оқы.</p>'; }
  }

  /* Куиз */
  P.quiz = () => {
    const qz = content(sv.book, sv.part).quiz, q = qz[qs.i];
    return `<section class="game"><div class="row" style="justify-content:space-between"><h3>Куиз</h3><div class="dots">${qz.map((_, i) => `<i class="${i <= qs.i ? 'on' : ''}"></i>`).join('')}</div></div>
      <p class="q">${esc(q.q)}</p><div class="opts">${q.o.map((o, i) => `<button class="opt${qs.picked === null ? '' : i === q.a ? ' right' : i === qs.picked ? ' wrong' : ''}" data-o="${i}" ${qs.picked === null ? '' : 'disabled'}>${esc(o)}</button>`).join('')}</div>
      ${qs.picked !== null ? `<div class="row" style="justify-content:space-between"><b style="color:${qs.picked === q.a ? 'var(--g)' : 'var(--r)'}">${qs.picked === q.a ? 'Дұрыс! Жарайсың.' : 'Дұрыс жауап жасылмен белгіленді.'}</b><button class="btn" id="qn">${qs.i < qz.length - 1 ? 'Келесі сұрақ' : 'Әрі қарай'}</button></div>` : ''}</section>`;
  };
  PA.quiz = () => {
    const qz = content(sv.book, sv.part).quiz;
    $$('[data-o]').forEach(b => (b.onclick = () => {
      qs.picked = +b.dataset.o;
      const ok = qs.picked === qz[qs.i].a;
      if (ok) qs.ok++;
      render();
      if (ok) burstAt($('.opt.right'), 40);
    }));
    const n = $('#qn');
    if (n) n.onclick = () => {
      if (qs.i < qz.length - 1) { qs.i++; qs.picked = null; render(); }
      else { sv.res.quiz = [qs.ok, qz.length]; qs = { i: 0, ok: 0, picked: null }; nextStep(); }
    };
  };

  /* Пазл */
  const imgCache = {};
  function puzzleImg(b) {
    if (b.cover) return fileUrl(b.cover);
    if (imgCache[b.id]) return imgCache[b.id];
    const c = document.createElement('canvas'); c.width = 300; c.height = 400;
    const x = c.getContext('2d');
    x.fillStyle = b.color; x.fillRect(0, 0, 300, 400);
    for (let k = 0; k < 26; k++) { x.fillStyle = `rgba(255,255,255,${0.06 + (k % 5) * 0.03})`; x.beginPath(); x.arc((k * 67) % 300, (k * 113) % 400, 14 + (k * 7) % 40, 0, Math.PI * 2); x.fill(); }
    x.fillStyle = '#FFC233'; x.beginPath(); x.moveTo(150, 60);
    for (let k = 1; k < 10; k++) { const r = k % 2 ? 16 : 40, a = -Math.PI / 2 + k * Math.PI / 5; x.lineTo(150 + r * Math.cos(a), 100 + r * Math.sin(a)); }
    x.closePath(); x.fill();
    x.fillStyle = '#fff'; x.textAlign = 'center'; x.font = '700 30px "Montserrat Alternates", sans-serif';
    const lines = []; let line = '';
    b.title.split(' ').forEach(w => { const t = line ? line + ' ' + w : w; if (x.measureText(t).width > 250) { lines.push(line); line = w; } else line = t; });
    lines.push(line);
    lines.forEach((l, k) => x.fillText(l, 150, 220 + k * 38));
    return (imgCache[b.id] = c.toDataURL('image/jpeg', 0.85));
  }
  P.puzzle = () => {
    const items = content(sv.book, sv.part).seq || [];
    if (!pz || pz.key !== sv.book + '/' + sv.part) {
      let t = shuffle([0, 1, 2, 3, 4, 5, 6, 7, 8]);
      while (t.every((v, i) => v === i)) t = shuffle(t);
      pz = { key: sv.book + '/' + sv.part, pool: shuffle(items), line: [], checked: false, tiles: t, sel: null, solved: false };
    }
    const done = pz.line.length === items.length, img = puzzleImg(H.books[sv.book]);
    return `<section class="game"><h3>Оқиға пазлы</h3><p class="small muted">Бөліктерді оқиға болған ретімен бас. Қате бассаң, жоғарыдағы бөлікті басып, қайтар.</p>
      <div class="seq-line">${pz.line.map((t, i) => { const cls = pz.checked ? (t === items[i] ? ' right' : ' wrong') : ''; return `<button class="seq-item piece${cls}" data-back="${i}" ${pz.checked ? 'disabled' : ''}><span class="k">${i + 1}</span>${esc(t)}</button>`; }).join('')}</div>
      ${pz.pool.length ? `<div class="seq-pool">${pz.pool.map((t, i) => `<button class="seq-item piece" data-pick="${i}">${esc(t)}</button>`).join('')}</div>` : ''}
      ${done && !pz.checked ? '<button class="btn gold" id="chk" style="align-self:flex-start">Тексеру</button>' : ''}
      ${pz.checked ? `<div class="row" style="justify-content:space-between"><b>${pz.line.filter((t, i) => t === items[i]).length} / ${items.length} дұрыс</b>${pz.line.some((t, i) => t !== items[i]) ? '<button class="btn alt" id="again">Қайта құрастыру</button>' : ''}</div>` : ''}
    </section>
    ${pz.checked ? `<section class="game"><div class="row" style="justify-content:space-between"><h3>Сурет пазлы</h3><span class="chip gold">${coin(14)} +5 бонус</span></div>
      <p class="small muted">Екі бөлікті кезекпен басып, орындарын ауыстыр. Кітап мұқабасын жина!</p>
      <div class="jig${pz.solved ? ' solved' : ''}">${pz.tiles.map((v, i) => `<button class="tile${pz.sel === i ? ' sel' : ''}" data-tile="${i}" ${pz.solved ? 'disabled' : ''} aria-label="Пазл бөлігі ${i + 1}" style="background-image:url('${img}');background-position:${(v % 3) * 50}% ${Math.floor(v / 3) * 50}%"></button>`).join('')}</div>
      ${pz.solved ? '<b style="color:var(--g)">Жарайсың! Пазл жиналды.</b>' : ''}
      <div class="row"><button class="btn" id="gn">${pz.solved ? 'Әрі қарай' : 'Пазлсыз әрі қарай'}</button></div></section>` : ''}`;
  };
  PA.puzzle = () => {
    const items = content(sv.book, sv.part).seq || [];
    $$('[data-pick]').forEach(b => (b.onclick = () => { pz.line.push(pz.pool.splice(+b.dataset.pick, 1)[0]); render(); }));
    $$('[data-back]').forEach(b => (b.onclick = () => { pz.pool.push(pz.line.splice(+b.dataset.back, 1)[0]); render(); }));
    const chk = $('#chk');
    if (chk) chk.onclick = () => { pz.checked = true; if (pz.first === undefined) pz.first = pz.line.filter((t, i) => t === items[i]).length; render(); };
    const ag = $('#again');
    if (ag) ag.onclick = () => { pz.checked = false; pz.pool = shuffle(items); pz.line = []; render(); };
    $$('[data-tile]').forEach(b => (b.onclick = () => {
      const i = +b.dataset.tile;
      if (pz.sel === null) pz.sel = i;
      else { const t = pz.tiles; [t[pz.sel], t[i]] = [t[i], t[pz.sel]]; pz.sel = null; if (t.every((v, k) => v === k)) { pz.solved = true; toast('Пазл жиналды! +5 монета'); } }
      render();
      if (pz.solved && !pz.cele) { pz.cele = 1; burstAt($('.jig'), 90); }
    }));
    const gn = $('#gn');
    if (gn) gn.onclick = () => { sv.res.game = [pz.first || 0, items.length]; sv.res.jig = pz.solved; pz = null; nextStep(); };
  };

  /* Комикс */
  const PANEL_TINT = ['var(--teal-soft)', 'var(--accent-soft)', 'color-mix(in srgb,var(--g) 14%,var(--paper))', 'color-mix(in srgb,var(--pink) 14%,var(--paper))'];
  P.comic = () => {
    const pans = (content(sv.book, sv.part).comic.panels || []).slice(0, 4);
    return `<section class="game"><div class="row" style="justify-content:space-between"><h3>Комикс</h3><span class="small muted">Соңғы кадрдағы сөзді өзің жаз</span></div>
      <div class="comic">${pans.map((p, i) => {
        const last = i === pans.length - 1, who = p.who || 'Кейіпкер';
        return `<figure class="panel" style="background:${PANEL_TINT[i % 4]}"><figcaption class="scene">${i + 1}. ${esc(p.scene)}</figcaption>
          <div class="talk"><span class="ava" aria-hidden="true">${esc(who.trim().charAt(0).toUpperCase())}</span><div class="bubble">${last ? `<input id="bub" placeholder="${esc(who)} не дейді?" aria-label="${esc(who)} не дейді?" maxlength="120">` : esc(p.say)}</div></div>
          <span class="who">${esc(who)}</span></figure>`;
      }).join('')}</div>
      <button class="btn gold" id="cdone" style="align-self:flex-start">Комиксті аяқтадым</button></section>`;
  };
  PA.comic = () => {
    $('#cdone').onclick = () => {
      const v = $('#bub').value.trim();
      if (!v) { toast('Соңғы кадрдағы кейіпкердің сөзін жаз'); return; }
      sv.res.comic = v; nextStep();
    };
  };

  /* Ойлан (дайын тапсырмасы жоқ кітапқа) */
  P.think = () => '<section class="game"><h3>Ойлан да, жаз</h3><p class="q">Бұл бөлімде не болды? Саған қай сәт ұнады және неге?</p><textarea id="open" placeholder="Менің ойымша…"></textarea><button class="btn" id="gn" style="align-self:flex-start">Суретке өту</button></section>';
  PA.think = () => {
    $('#gn').onclick = () => {
      const v = $('#open').value.trim();
      if (v.split(/\s+/).length < 3) { toast('Ойыңды кемінде бір сөйлеммен жаз'); return; }
      sv.res.open = v; sv.res.game = [1, 2]; nextStep();
    };
  };

  /* Сурет */
  const PALETTE = ['#1B1B1B', '#D64545', '#F08A24', '#F4C430', '#2E9E5B', '#2D7FD3', '#7A4FC9', '#8B5A2B', '#F28DB2', '#FFFFFF'];
  let pen = { c: '#2D7FD3', s: 8 }, dirty = false, saving = false;
  P.draw = () => {
    const c = content(sv.book, sv.part);
    const prompt = c && c.draw ? c.draw : 'Бұл бөлімді оқығанда көз алдыңа не елестеді? Суретін сал.';
    return `<section class="game"><h3>Шығармашылық тапсырма</h3><p class="q" id="dprompt">${esc(prompt)}</p>
      <p class="small muted">Суретті осы алаңда салуға немесе қағазға салып, суретін енгізуге болады.</p>
      <div class="draw"><canvas id="cv" width="800" height="500" aria-label="Сурет салатын алаң"></canvas>
        <div class="tools">
          <div class="swatches" role="group" aria-label="Түс">${PALETTE.map(p => `<button class="sw" style="background:${p}" data-sw="${p}" aria-pressed="${p === pen.c}" aria-label="${p === '#FFFFFF' ? 'Өшіргіш' : 'Түс'}"></button>`).join('')}</div>
          <div class="sizes" role="group" aria-label="Қалам өлшемі">${[4, 8, 20].map(s => `<button data-sz="${s}" aria-pressed="${s === pen.s}" aria-label="Қалам ${s}"><i style="width:${s / 1.6 + 3}px;height:${s / 1.6 + 3}px"></i></button>`).join('')}</div>
          <button class="btn alt" id="clr">Тазалау</button>
          <div class="upl"><span class="small muted">Қағазға салдың ба?</span><label class="btn" for="upfile" style="color:#fff;font-size:15px;text-align:center;cursor:pointer">Суретті енгізу</label><input id="upfile" type="file" accept="image/*" hidden><span class="small muted">Суретіңді телефонмен суретке түсіріп, осында жүкте.</span></div>
        </div></div>
      <label>Суретің туралы бір сөйлем жаз<input id="cap" maxlength="300" placeholder="Мен … салдым, себебі …"></label>
      <div class="row"><button class="btn gold" id="save">Суретті сақтап, бөлімді аяқтау</button></div></section>`;
  };
  PA.draw = () => {
    const cv = $('#cv'), x = cv.getContext('2d');
    dirty = false;
    const clear = () => { x.fillStyle = '#fff'; x.fillRect(0, 0, cv.width, cv.height); };
    clear(); x.lineCap = 'round'; x.lineJoin = 'round';
    let on = false, last;
    const pos = e => { const r = cv.getBoundingClientRect(); return [(e.clientX - r.left) * cv.width / r.width, (e.clientY - r.top) * cv.height / r.height]; };
    const line = (a, b) => { x.strokeStyle = pen.c; x.lineWidth = pen.s * (pen.c === '#FFFFFF' ? 2 : 1); x.beginPath(); x.moveTo(a[0], a[1]); x.lineTo(b[0], b[1]); x.stroke(); };
    cv.onpointerdown = e => { on = true; cv.setPointerCapture(e.pointerId); last = pos(e); line(last, [last[0] + 0.1, last[1] + 0.1]); dirty = true; };
    cv.onpointermove = e => { if (!on) return; const p = pos(e); line(last, p); last = p; };
    cv.onpointerup = cv.onpointercancel = () => (on = false);
    $$('[data-sw]').forEach(b => (b.onclick = () => { pen.c = b.dataset.sw; $$('[data-sw]').forEach(y => y.setAttribute('aria-pressed', y === b)); }));
    $$('[data-sz]').forEach(b => (b.onclick = () => { pen.s = +b.dataset.sz; $$('[data-sz]').forEach(y => y.setAttribute('aria-pressed', y === b)); }));
    $('#clr').onclick = () => { clear(); dirty = false; };
    $('#upfile').onchange = e => {
      const f = e.target.files[0]; e.target.value = '';
      if (!f) return;
      if (!f.type.startsWith('image/')) { toast('Сурет файлын таңда (JPG немесе PNG)'); return; }
      const url = URL.createObjectURL(f), im = new Image();
      im.onload = () => { clear(); const k = Math.min(cv.width / im.width, cv.height / im.height), w = im.width * k, h = im.height * k; x.drawImage(im, (cv.width - w) / 2, (cv.height - h) / 2, w, h); URL.revokeObjectURL(url); dirty = true; toast('Сурет енгізілді. Қаласаң, үстінен сала аласың'); };
      im.onerror = () => { URL.revokeObjectURL(url); toast('Бұл суретті ашу мүмкін болмады. Басқа файл таңда'); };
      im.src = url;
    };
    $('#save').onclick = async () => {
      if (!dirty) { toast('Алдымен сурет салып көр'); return; }
      if (saving) return;
      saving = true;
      const btn = $('#save'); btn.disabled = true; btn.textContent = 'Сақталып жатыр…';
      try {
        const r = await api('/api/student/complete', { method: 'POST', body: {
          bookId: sv.book, part: sv.part, quiz: sv.res.quiz || [0, 0], game: sv.res.game || [0, 0], jig: !!sv.res.jig,
          comic: sv.res.comic || '', open: sv.res.open || '',
          drawing: { img: cv.toDataURL('image/jpeg', 0.75), cap: $('#cap').value.trim(), prompt: $('#dprompt').textContent },
        } });
        H.progress = r.progress; H.coins = r.coins; sv.score = r.score;
        nextStep();
      } catch (e) { toast(e.message, 4000); btn.disabled = false; btn.textContent = 'Суретті сақтап, бөлімді аяқтау'; }
      finally { saving = false; }
    };
  };

  /* Аяқталды */
  P.done = () => {
    const s = sv.score ?? 0, n = s >= 0.85 ? 3 : s >= 0.5 ? 2 : 1, b = H.books[sv.book], last = sv.part >= b.parts.length - 1;
    const p = progressOf(b.id)[sv.part] || {}, earned = 10 + (n === 3 ? 5 : 0) + (p.jig ? 5 : 0);
    if (bookFinished(b.id) && last) return `<section class="game done-box finish">
      <div class="medal" style="--mc:${esc(b.color)}" aria-hidden="true">${star(54, true)}</div>
      <h2>Құттықтаймыз! «${esc(b.title)}» кітабын толық оқыдың!</h2>
      <div class="row" style="justify-content:center"><span class="chip gold big">${coin(20)} +${earned} монета</span><span class="chip gold big">${coin(20)} +50 бонус</span></div>
      <p class="muted">Жаңа медаль қазынаңа қосылды. Барлығы: <b>${H.coins}</b> монета.</p>
      <button class="btn gold" id="shelf">Қазынама өту</button></section>`;
    return `<section class="game done-box"><div class="bigstars">${[1, 2, 3].map(k => star(56, k <= n)).join('')}</div>
      <h2>${n === 3 ? 'Керемет! Бөлімді толық меңгердің.' : n === 2 ? 'Жарайсың! Тағы аздап жаттықсаң, үш жұлдыз аласың.' : 'Бастама жақсы! Бөлімді тағы бір рет оқып шық.'}</h2>
      <span class="chip gold big">${coin(20)} +${earned} монета</span>
      <p class="muted">Суретің мұғаліміңе жіберілді.</p>
      <div class="row" style="justify-content:center">${last ? '<button class="btn gold" id="shelf">Сөреге оралу</button>' : '<button class="btn gold" id="nextp">Келесі бөлімге</button>'}<button class="btn alt" id="redo">Бөлімді қайталау</button></div></section>`;
  };
  PA.done = () => {
    const fin = $('.finish');
    confetti(fin ? 220 : 120);
    if (fin) { setTimeout(() => confetti(160, innerWidth * 0.2, innerHeight * 0.3), 450); setTimeout(() => confetti(160, innerWidth * 0.8, innerHeight * 0.3), 800); }
    const s = $('#shelf'); if (s) s.onclick = () => go({ screen: 'shelf' });
    const np = $('#nextp'); if (np) np.onclick = () => go({ part: sv.part + 1, step: 'read', res: {} });
    const rd = $('#redo'); if (rd) rd.onclick = () => go({ step: 'read', res: {} });
  };

  return { start };
})();
