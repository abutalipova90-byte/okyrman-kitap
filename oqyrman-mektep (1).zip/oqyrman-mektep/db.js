// Қарапайым JSON дерекқор: бір файл, қауіпсіз жазу (алдымен уақытша файл, кейін ауыстыру).
// Бір мектепке (бірнеше жүз оқушыға) жеткілікті. Резервтік көшірме үшін data/ қалтасын көшіріңіз.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

let file = null;
let data = null;
let timer = null;

function init(f) {
  file = f;
  fs.mkdirSync(path.dirname(f), { recursive: true });
  data = fs.existsSync(f) ? JSON.parse(fs.readFileSync(f, 'utf8')) : {};
  for (const k of ['users', 'classes', 'books', 'drawings']) data[k] = data[k] || [];
  for (const k of ['sessions', 'progress', 'overrides']) data[k] = data[k] || {};
  data.meta = data.meta || { createdAt: new Date().toISOString() };
  write();
}

function write() {
  clearTimeout(timer);
  timer = null;
  const tmp = file + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data));
  fs.renameSync(tmp, file);
}

// Жиі өзгерістерді біріктіріп жазады
function save() {
  if (!timer) timer = setTimeout(write, 150);
}

function flush() {
  if (timer) write();
}

module.exports = {
  init,
  save,
  flush,
  get d() { return data; },
  id: () => crypto.randomUUID(),
};
