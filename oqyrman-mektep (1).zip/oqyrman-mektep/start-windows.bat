@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js орнатылмаған. https://nodejs.org сайтынан LTS нұсқасын орнатыңыз.
  pause
  exit /b 1
)
if not exist node_modules (
  echo Қажетті модульдер орнатылып жатыр...
  call npm install --omit=dev
)
if not exist .env copy .env.example .env >nul
echo.
echo Сайтты тоқтату үшін осы терезені жабыңыз.
node server.js
pause
